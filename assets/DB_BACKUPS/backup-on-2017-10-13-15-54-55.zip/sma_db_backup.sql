#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'HARUN', 'SEVENTHSIN', 'YOS SUDARSO 8-9', 'PALU', 'SULTENG', '-', 'INDONESIA', '012345678', 'harun@seventhsin.com', 'logo.png', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: bom
#

DROP TABLE IF EXISTS bom;

CREATE TABLE `bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(50) NOT NULL,
  `idBahanBaku` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduk` (`idProduk`),
  KEY `idBahanBaku` (`idBahanBaku`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=latin1;

INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (1, 'mt02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (2, 'mt03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (3, 'mt04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (4, 'mt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (5, 'mt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (6, 'mt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (7, 'mt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (8, 'mt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (9, 'mt08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (10, 'mt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (11, 'mt10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (12, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (13, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (14, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (15, 'mt12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (16, 'mt13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (17, 'bt01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (18, 'bt01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (19, 'bt02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (20, 'bt03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (21, 'bt04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (22, 'bt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (23, 'bt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (24, 'bt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (25, 'bt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (26, 'bt08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (27, 'bt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (28, 'bt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (29, 'bt10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (30, 'bt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (31, 'bt12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (32, 'bt13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (33, 'bt14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (34, 'bt15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (35, 'bt16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (36, 'bt17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (37, 'bt18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (38, 'bt19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (39, 'bt20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (40, 'bt21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (41, 'bt22', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (42, 'bt23', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (43, 'bt24', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (44, 'ot01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (45, 'ot02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (46, 'ot03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (47, 'ot04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (48, 'ot05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (49, 'ot06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (50, 'ot07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (51, 'ot08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (52, 'ot09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (53, 'ot10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (54, 're01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (55, 're02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (56, 're03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (57, 're04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (58, 're05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (59, 're06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (60, 're07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (61, 're08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (62, 're09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (63, 're10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (64, 're11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (65, 're12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (66, 're13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (67, 're14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (68, 're15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (69, 're16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (70, 're17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (71, 're18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (72, 're19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (73, 're20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (74, 're21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (75, 'sy01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (76, 'sy02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (77, 'sy03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (78, 'sy04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (79, 'sy05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (80, 'sy06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (81, 'sy07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (82, 'sy07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (83, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (84, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (85, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (86, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (87, 'sy09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (88, 'sy10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (89, 'sy11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (90, 'sy12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (91, 'sy13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (92, 'sy13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (93, 'sy14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (94, 'sy15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (95, 'sy16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (96, 'sy17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (97, 'sy18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (98, 'sy19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (99, 'sy20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (100, 'sy21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (101, 'sy22', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (102, 'sy23', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (103, 'sy24', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (104, 'sy25', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (105, 'sy26', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (106, 'sy26', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (107, 'sy27', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (108, 'sy27', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (109, 'sy28', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (110, 'sy29', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (111, 'sy30', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (112, 'sy30', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (113, 'sy31', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (114, 'st01', 'mt01', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (115, 'st01', 'bt21', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (116, 'st01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (117, 'sy32', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (118, 'mt01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (119, 'st01', 'mt01', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (120, 'st01', 'sy32', 80);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (121, 'st01', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (122, 'st01', 're18', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (123, 'st01', 're08', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (124, 'st01', 're02', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (125, 'st01', 'bt05', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (126, 'st01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (127, 'st02', 'sy32', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (128, 'st02', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (129, 'st02', 're18', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (130, 'st02', 're08', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (131, 'st02', 're02', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (132, 'st02', 'bt05', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (133, 'st02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (134, 'st03', 'mt05', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (135, 'st03', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (136, 'st03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (137, 'st04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (138, 'st04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (139, 'st05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (140, 'st05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (141, 'st06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (142, 'st06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (143, 'st07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (144, 'st08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (145, 'st09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (146, 'st10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (147, 'st11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (148, 'st12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (149, 'st13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (150, 'sy33', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (151, 'sy34', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (152, 'sn01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (153, 'ot11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (154, 'sn02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (155, 'sn03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (156, 'sn04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (157, 'sn04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (158, 'sn05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (159, 'sn05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (160, 'sp01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (161, 'sp02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (162, 'sn06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (163, 'ns01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (164, 'ns02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (165, 'ns03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (166, 'ns04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (167, 'ns05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (168, 'sy35', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (169, 'ot12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (170, 'pz01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (171, 'pz02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (172, 'sy36', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (174, 'sy37', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (176, 'bt25', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (177, 'sl', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (178, 'sn07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (179, 'sn08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (180, 'sn09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (181, 'sn10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (182, 'sn10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (183, 'sn11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (184, 'sn12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (185, 'sn12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (186, 'sn13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (187, 'pz05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (188, 'pz06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (189, 'ns06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (190, 'es01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (191, 'es02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (192, 'es03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (193, 'es03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (194, 'jc01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (195, 'jc02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (196, 'jc03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (197, 'jc04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (198, 'jc05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (199, 'jc06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (200, 'jc07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (201, 'jc08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (202, 'bt26', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (203, 'jc09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (204, 'bt27', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (205, 'jc10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (206, 'bt28', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (207, 'jc11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (208, 'bt29', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (209, 'jc12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (210, 'jc13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (211, 'jc14', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (212, 'jc15', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (213, 'jc16', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (214, 'jc16', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (215, 'jc17', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (216, 'jc18', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (217, 'jc19', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (218, 'jc20', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (219, 'jc21', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (220, 'jc23', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (221, 'jc24', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (222, 'jc26', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (223, 'ac01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (224, 'ac01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (225, 'ac02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (226, 'ac03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (227, 'ac04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (228, 'ac05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (229, 'ac06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (230, 'ac07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (231, 'ac08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (232, 'ac09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (233, 'ac10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (234, 'ac11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (235, 'ac12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (236, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (237, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (238, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (239, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (240, 'pz03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (241, 'pz03', 'mt02', 0);


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (2, 'bb02', 'botol dan kaleng');
INSERT INTO categories (`id`, `code`, `name`) VALUES (3, 'bb01', 'daging');
INSERT INTO categories (`id`, `code`, `name`) VALUES (4, 'bb03', 'tepung dan lain-lain');
INSERT INTO categories (`id`, `code`, `name`) VALUES (5, 'bb04', 'rempah-rempah');
INSERT INTO categories (`id`, `code`, `name`) VALUES (6, 'bb05', 'sayuran dan buah');
INSERT INTO categories (`id`, `code`, `name`) VALUES (7, 'fd', 'makanan');
INSERT INTO categories (`id`, `code`, `name`) VALUES (8, 'mm02', 'minuman');
INSERT INTO categories (`id`, `code`, `name`) VALUES (9, 'ic01', 'ice cream');
INSERT INTO categories (`id`, `code`, `name`) VALUES (10, 'sa01', 'bahan saos');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');
INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'GENERAL CUSTOMER', 'seventhsin', 'YOS SUDARSO 8-9', 'PALU', 'SULTENG', '-', 'INDONESIA', '0123456789', 'general@seventhsin.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yyyy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yyyy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS log;

CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(25) NOT NULL,
  `qty` int(11) NOT NULL,
  `namaTransaksi` varchar(100) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=latin1;

INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1, 'mt01', 0, 'Tambah Data Produk', '2017-10-11 19:36:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (2, 'mt02', 0, 'Tambah Data Produk', '2017-10-11 19:41:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (3, 'mt03', 0, 'Tambah Data Produk', '2017-10-11 19:48:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (4, 'mt04', 0, 'Tambah Data Produk', '2017-10-11 19:56:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (5, 'mt05', 0, 'Tambah Data Produk', '2017-10-11 19:58:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (6, 'mt06', 0, 'Tambah Data Produk', '2017-10-11 19:59:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (7, 'mt07', 0, 'Tambah Data Produk', '2017-10-11 20:00:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (8, 'mt08', 0, 'Tambah Data Produk', '2017-10-11 20:02:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (9, 'mt09', 0, 'Tambah Data Produk', '2017-10-11 20:05:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (10, 'mt10', 0, 'Tambah Data Produk', '2017-10-11 20:06:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (11, 'mt11', 0, 'Tambah Data Produk', '2017-10-11 20:09:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (12, 'mt12', 0, 'Tambah Data Produk', '2017-10-11 20:12:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (13, 'mt13', 0, 'Tambah Data Produk', '2017-10-11 20:16:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (14, 'bt01', 0, 'Tambah Data Produk', '2017-10-11 20:18:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (15, 'bt02', 0, 'Tambah Data Produk', '2017-10-11 20:19:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (16, 'bt03', 0, 'Tambah Data Produk', '2017-10-11 20:20:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (17, 'bt04', 0, 'Tambah Data Produk', '2017-10-11 20:21:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (18, 'bt05', 0, 'Tambah Data Produk', '2017-10-11 20:21:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (19, 'bt06', 0, 'Tambah Data Produk', '2017-10-11 20:22:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (20, 'bt07', 0, 'Tambah Data Produk', '2017-10-11 20:23:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (21, 'bt08', 0, 'Tambah Data Produk', '2017-10-11 20:23:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (22, 'bt09', 0, 'Tambah Data Produk', '2017-10-11 20:25:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (23, 'bt10', 0, 'Tambah Data Produk', '2017-10-11 20:25:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (24, 'bt11', 0, 'Tambah Data Produk', '2017-10-11 20:26:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (25, 'bt12', 0, 'Tambah Data Produk', '2017-10-11 20:26:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (26, 'bt13', 0, 'Tambah Data Produk', '2017-10-11 20:27:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (27, 'bt14', 0, 'Tambah Data Produk', '2017-10-11 20:37:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (28, 'bt15', 0, 'Tambah Data Produk', '2017-10-11 20:37:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (29, 'bt16', 0, 'Tambah Data Produk', '2017-10-11 20:38:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (30, 'bt17', 0, 'Tambah Data Produk', '2017-10-11 20:39:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (31, 'bt18', 0, 'Tambah Data Produk', '2017-10-11 20:39:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (32, 'bt19', 0, 'Tambah Data Produk', '2017-10-11 20:40:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (33, 'bt20', 0, 'Tambah Data Produk', '2017-10-11 20:40:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (34, 'bt21', 0, 'Tambah Data Produk', '2017-10-11 20:41:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (35, 'bt22', 0, 'Tambah Data Produk', '2017-10-11 20:41:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (36, 'bt23', 0, 'Tambah Data Produk', '2017-10-11 20:42:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (37, 'bt24', 0, 'Tambah Data Produk', '2017-10-11 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (38, 'ot01', 0, 'Tambah Data Produk', '2017-10-11 20:44:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (39, 'ot02', 0, 'Tambah Data Produk', '2017-10-11 20:44:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (40, 'ot03', 0, 'Tambah Data Produk', '2017-10-11 20:45:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (41, 'ot04', 0, 'Tambah Data Produk', '2017-10-11 20:45:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (42, 'ot05', 0, 'Tambah Data Produk', '2017-10-11 20:45:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (43, 'ot06', 0, 'Tambah Data Produk', '2017-10-11 20:46:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (44, 'ot07', 0, 'Tambah Data Produk', '2017-10-11 20:47:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (45, 'ot08', 0, 'Tambah Data Produk', '2017-10-11 20:48:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (46, 'ot09', 0, 'Tambah Data Produk', '2017-10-11 20:48:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (47, 'ot10', 0, 'Tambah Data Produk', '2017-10-11 20:49:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (48, 're01', 0, 'Tambah Data Produk', '2017-10-11 20:50:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (49, 're02', 0, 'Tambah Data Produk', '2017-10-11 20:51:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (50, 're03', 0, 'Tambah Data Produk', '2017-10-11 20:52:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (51, 're04', 0, 'Tambah Data Produk', '2017-10-11 20:52:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (52, 're05', 0, 'Tambah Data Produk', '2017-10-11 20:53:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (53, 're06', 0, 'Tambah Data Produk', '2017-10-11 20:53:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (54, 're07', 0, 'Tambah Data Produk', '2017-10-11 20:54:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (55, 're08', 0, 'Tambah Data Produk', '2017-10-11 20:54:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (56, 're09', 0, 'Tambah Data Produk', '2017-10-11 21:27:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (57, 're10', 0, 'Tambah Data Produk', '2017-10-11 21:27:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (58, 're11', 0, 'Tambah Data Produk', '2017-10-11 21:28:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (59, 're12', 0, 'Tambah Data Produk', '2017-10-11 21:28:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (60, 're13', 0, 'Tambah Data Produk', '2017-10-11 21:29:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (61, 're14', 0, 'Tambah Data Produk', '2017-10-11 21:29:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (62, 're15', 0, 'Tambah Data Produk', '2017-10-11 21:29:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (63, 're16', 0, 'Tambah Data Produk', '2017-10-11 21:30:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (64, 're17', 0, 'Tambah Data Produk', '2017-10-11 21:30:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (65, 're18', 0, 'Tambah Data Produk', '2017-10-11 21:31:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (66, 're19', 0, 'Tambah Data Produk', '2017-10-11 21:31:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (67, 're20', 0, 'Tambah Data Produk', '2017-10-11 21:47:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (68, 're21', 0, 'Tambah Data Produk', '2017-10-11 21:48:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (69, 'sy01', 0, 'Tambah Data Produk', '2017-10-11 21:50:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (70, 'sy02', 0, 'Tambah Data Produk', '2017-10-11 21:51:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (71, 'sy03', 0, 'Tambah Data Produk', '2017-10-11 21:51:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (72, 'sy04', 0, 'Tambah Data Produk', '2017-10-11 21:52:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (73, 'sy05', 0, 'Tambah Data Produk', '2017-10-11 21:52:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (74, 'sy06', 0, 'Tambah Data Produk', '2017-10-11 21:53:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (75, 'sy07', 0, 'Tambah Data Produk', '2017-10-11 21:54:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (76, 'sy08', 0, 'Tambah Data Produk', '2017-10-11 22:05:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (77, 'sy08', 0, 'Tambah Data Produk', '2017-10-11 22:06:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (78, 'sy09', 0, 'Tambah Data Produk', '2017-10-11 22:07:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (79, 'sy10', 0, 'Tambah Data Produk', '2017-10-11 22:08:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (80, 'sy11', 0, 'Tambah Data Produk', '2017-10-11 22:08:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (81, 'sy12', 0, 'Tambah Data Produk', '2017-10-11 22:09:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (82, 'sy13', 0, 'Tambah Data Produk', '2017-10-11 22:09:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (83, 'sy14', 0, 'Tambah Data Produk', '2017-10-11 22:10:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (84, 'sy15', 0, 'Tambah Data Produk', '2017-10-11 22:10:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (85, 'sy16', 0, 'Tambah Data Produk', '2017-10-11 22:11:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (86, 'sy17', 0, 'Tambah Data Produk', '2017-10-11 22:11:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (87, 'sy18', 0, 'Tambah Data Produk', '2017-10-11 22:12:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (88, 'sy19', 0, 'Tambah Data Produk', '2017-10-11 22:12:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (89, 'sy20', 0, 'Tambah Data Produk', '2017-10-11 22:13:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (90, 'sy21', 0, 'Tambah Data Produk', '2017-10-11 22:13:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (91, 'sy22', 0, 'Tambah Data Produk', '2017-10-11 22:14:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (92, 'sy23', 0, 'Tambah Data Produk', '2017-10-11 22:14:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (93, 'sy24', 0, 'Tambah Data Produk', '2017-10-11 22:15:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (94, 'sy25', 0, 'Tambah Data Produk', '2017-10-11 22:15:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (95, 'sy26', 0, 'Tambah Data Produk', '2017-10-11 22:16:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (96, 'sy27', 0, 'Tambah Data Produk', '2017-10-11 22:16:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (97, 'sy28', 0, 'Tambah Data Produk', '2017-10-11 22:17:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (98, 'sy29', 0, 'Tambah Data Produk', '2017-10-11 22:18:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (99, 'sy30', 0, 'Tambah Data Produk', '2017-10-11 22:18:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (100, 'sy31', 0, 'Tambah Data Produk', '2017-10-11 22:19:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (101, 'st01', 0, 'Tambah Data Produk', '2017-10-11 22:24:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (102, 'sy32', 0, 'Tambah Data Produk', '2017-10-11 22:26:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (103, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (104, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (105, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (106, 'st01', 1, 'Penjualan Produk', '2017-10-11 22:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (107, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (108, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (109, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-11 22:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (110, 'st01', 1, 'Penjualan Produk', '2017-10-11 22:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (111, 'mt01', 0, 'Tambah Data Produk', '2017-10-11 23:28:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (112, 'st01', 0, 'Tambah Data Produk', '2017-10-11 23:32:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (113, 'st02', 0, 'Tambah Data Produk', '2017-10-11 23:35:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (114, 'st03', 0, 'Tambah Data Produk', '2017-10-11 23:48:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (115, 'st04', 0, 'Tambah Data Produk', '2017-10-11 23:51:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (116, 'st05', 0, 'Tambah Data Produk', '2017-10-11 23:53:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (117, 'st06', 0, 'Tambah Data Produk', '2017-10-11 23:55:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (118, 'st07', 0, 'Tambah Data Produk', '2017-10-11 23:59:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (119, 'st08', 0, 'Tambah Data Produk', '2017-10-12 00:00:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (120, 'st09', 0, 'Tambah Data Produk', '2017-10-12 00:01:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (121, 'st10', 0, 'Tambah Data Produk', '2017-10-12 00:02:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (122, 'st11', 0, 'Tambah Data Produk', '2017-10-12 00:03:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (123, 'st12', 0, 'Tambah Data Produk', '2017-10-12 00:03:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (124, 'st13', 0, 'Tambah Data Produk', '2017-10-12 00:04:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (125, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (126, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (127, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (128, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (129, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (130, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (131, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (132, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (133, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (134, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (135, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (136, 'st01', 1, 'Penjualan Produk', '2017-10-12 00:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (137, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (138, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (139, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (140, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (141, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (142, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (143, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (144, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (145, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (146, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (147, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (148, 'st01', 1, 'Penjualan Produk', '2017-10-12 00:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (149, 'sy33', 0, 'Tambah Data Produk', '2017-10-12 01:08:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (150, 'sy34', 0, 'Tambah Data Produk', '2017-10-12 01:09:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (151, 'sn01', 0, 'Tambah Data Produk', '2017-10-12 01:17:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (152, 'ot11', 0, 'Tambah Data Produk', '2017-10-12 01:18:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (153, 'sn02', 0, 'Tambah Data Produk', '2017-10-12 01:21:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (154, 'sn03', 0, 'Tambah Data Produk', '2017-10-12 01:26:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (155, 'sn04', 0, 'Tambah Data Produk', '2017-10-12 01:29:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (156, 'sn05', 0, 'Tambah Data Produk', '2017-10-12 01:32:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (157, 'sp01', 0, 'Tambah Data Produk', '2017-10-12 01:35:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (158, 'sp02', 0, 'Tambah Data Produk', '2017-10-12 01:37:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (159, 'sn06', 0, 'Tambah Data Produk', '2017-10-12 01:39:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (160, 'ns01', 0, 'Tambah Data Produk', '2017-10-12 01:41:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (161, 'ns02', 0, 'Tambah Data Produk', '2017-10-12 01:44:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (162, 'ns03', 0, 'Tambah Data Produk', '2017-10-12 01:46:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (163, 'ns04', 0, 'Tambah Data Produk', '2017-10-12 01:47:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (164, 'ns05', 0, 'Tambah Data Produk', '2017-10-12 01:55:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (165, 'sy35', 0, 'Tambah Data Produk', '2017-10-12 01:58:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (166, 'ot12', 0, 'Tambah Data Produk', '2017-10-12 01:59:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (167, 'pz01', 0, 'Tambah Data Produk', '2017-10-12 02:01:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (168, 'pz02', 0, 'Tambah Data Produk', '2017-10-12 02:04:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (169, 'sy36', 0, 'Tambah Data Produk', '2017-10-12 02:06:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (170, 'pz03', 0, 'Tambah Data Produk', '2017-10-12 02:07:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (171, 'sy37', 0, 'Tambah Data Produk', '2017-10-12 02:08:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (172, 'pz04', 0, 'Tambah Data Produk', '2017-10-12 02:10:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (173, 'bt25', 0, 'Tambah Data Produk', '2017-10-12 02:11:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (174, 'sl', 0, 'Tambah Data Produk', '2017-10-12 02:13:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (175, 'sn07', 0, 'Tambah Data Produk', '2017-10-12 02:17:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (176, 'sn08', 0, 'Tambah Data Produk', '2017-10-12 02:19:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (177, 'sn09', 0, 'Tambah Data Produk', '2017-10-12 02:21:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (178, 'sn10', 0, 'Tambah Data Produk', '2017-10-12 02:22:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (179, 'sn11', 0, 'Tambah Data Produk', '2017-10-12 02:22:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (180, 'sn12', 0, 'Tambah Data Produk', '2017-10-12 02:23:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (181, 'sn13', 0, 'Tambah Data Produk', '2017-10-12 02:23:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (182, 'pz05', 0, 'Tambah Data Produk', '2017-10-12 02:24:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (183, 'pz06', 0, 'Tambah Data Produk', '2017-10-12 02:25:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (184, 'ns06', 0, 'Tambah Data Produk', '2017-10-12 02:25:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (185, 'es01', 0, 'Tambah Data Produk', '2017-10-12 02:26:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (186, 'es02', 0, 'Tambah Data Produk', '2017-10-12 02:27:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (187, 'es03', 0, 'Tambah Data Produk', '2017-10-12 02:27:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (188, 'jc01', 0, 'Tambah Data Produk', '2017-10-12 02:57:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (189, 'jc02', 0, 'Tambah Data Produk', '2017-10-12 02:58:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (190, 'jc03', 0, 'Tambah Data Produk', '2017-10-12 02:59:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (191, 'jc04', 0, 'Tambah Data Produk', '2017-10-12 03:00:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (192, 'jc05', 0, 'Tambah Data Produk', '2017-10-12 03:01:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (193, 'jc06', 0, 'Tambah Data Produk', '2017-10-12 03:03:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (194, 'jc07', 0, 'Tambah Data Produk', '2017-10-12 03:04:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (195, 'jc08', 0, 'Tambah Data Produk', '2017-10-12 03:05:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (196, 'bt26', 0, 'Tambah Data Produk', '2017-10-12 03:09:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (197, 'jc09', 0, 'Tambah Data Produk', '2017-10-12 03:10:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (198, 'bt27', 0, 'Tambah Data Produk', '2017-10-12 03:11:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (199, 'jc10', 0, 'Tambah Data Produk', '2017-10-12 03:13:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (200, 'bt28', 0, 'Tambah Data Produk', '2017-10-12 03:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (201, 'jc11', 0, 'Tambah Data Produk', '2017-10-12 03:14:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (202, 'bt29', 0, 'Tambah Data Produk', '2017-10-12 03:16:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (203, 'jc12', 0, 'Tambah Data Produk', '2017-10-12 03:17:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (204, 'jc13', 0, 'Tambah Data Produk', '2017-10-12 03:19:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (205, 'jc14', 0, 'Tambah Data Produk', '2017-10-12 03:19:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (206, 'jc15', 0, 'Tambah Data Produk', '2017-10-12 03:20:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (207, 'jc16', 0, 'Tambah Data Produk', '2017-10-12 04:12:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (208, 'jc17', 0, 'Tambah Data Produk', '2017-10-12 04:12:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (209, 'jc18', 0, 'Tambah Data Produk', '2017-10-12 04:13:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (210, 'jc19', 0, 'Tambah Data Produk', '2017-10-12 04:14:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (211, 'jc20', 0, 'Tambah Data Produk', '2017-10-12 04:15:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (212, 'jc21', 0, 'Tambah Data Produk', '2017-10-12 04:17:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (213, 'jc23', 0, 'Tambah Data Produk', '2017-10-12 04:20:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (214, 'jc24', 0, 'Tambah Data Produk', '2017-10-12 04:20:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (215, 'jc26', 0, 'Tambah Data Produk', '2017-10-12 04:21:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (216, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 04:37:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (217, 'sn11', 1, 'Penjualan Produk', '2017-10-12 04:37:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (218, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 04:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (219, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 04:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (220, 'sn10', 1, 'Penjualan Produk', '2017-10-12 04:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (221, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 04:52:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (222, 'sn11', 1, 'Penjualan Produk', '2017-10-12 04:52:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (223, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 04:54:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (224, 'sn11', 1, 'Penjualan Produk', '2017-10-12 04:54:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (225, 'ac01', 0, 'Tambah Data Produk', '2017-10-12 23:20:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (226, 'ac02', 0, 'Tambah Data Produk', '2017-10-12 23:21:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (227, 'ac03', 0, 'Tambah Data Produk', '2017-10-12 23:22:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (228, 'ac04', 0, 'Tambah Data Produk', '2017-10-12 23:24:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (229, 'ac05', 0, 'Tambah Data Produk', '2017-10-12 23:24:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (230, 'ac06', 0, 'Tambah Data Produk', '2017-10-12 23:25:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (231, 'ac07', 0, 'Tambah Data Produk', '2017-10-12 23:26:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (232, 'ac08', 0, 'Tambah Data Produk', '2017-10-12 23:28:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (233, 'ac09', 0, 'Tambah Data Produk', '2017-10-12 23:29:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (234, 'ac10', 0, 'Tambah Data Produk', '2017-10-12 23:32:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (235, 'ac11', 0, 'Tambah Data Produk', '2017-10-12 23:33:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (236, 'ac12', 0, 'Tambah Data Produk', '2017-10-12 23:34:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (237, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 15:00:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (238, 'jc26', 1, 'Penjualan Produk', '2017-10-13 15:00:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (239, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 15:06:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (240, 'jc26', 1, 'Penjualan Produk', '2017-10-13 15:06:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (241, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 15:17:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (242, 'jc26', 1, 'Penjualan Produk', '2017-10-13 15:17:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (243, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 15:28:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (244, 'ns05', 1, 'Penjualan Produk', '2017-10-13 15:28:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (245, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 00:35:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (246, 'ns05', 1, 'Penjualan Produk', '2017-10-13 00:35:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (247, 'pz04', 0, 'Edit Data Produk', '2017-10-13 01:03:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (248, 'pz04', 0, 'Edit Data Produk', '2017-10-13 01:03:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (249, 'pz03', 0, 'Edit Data Produk', '2017-10-13 01:03:13');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS menu;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `ext_1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 7, 1, 1, 'yes', '', '', '', '');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `size` varchar(55) NOT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  `jml_cf1` int(11) NOT NULL,
  `jml_cf2` int(11) NOT NULL,
  `jml_cf3` int(11) NOT NULL,
  `jml_cf4` int(11) NOT NULL,
  `jml_cf5` int(11) NOT NULL,
  `jml_cf6` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `track_quantity` tinyint(4) DEFAULT '1',
  `details` varchar(1000) DEFAULT NULL,
  `menu` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (2, 'mt02', 'tenderloin buff', 'gr', 'gr', '90.00', '90.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (3, 'mt03', 'oxtail', 'gr', 'gr', '130.00', '130.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (4, 'mt04', 'backrib', 'gr', 'gr', '95.00', '95.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (5, 'mt05', 'chicken breast', 'gr', 'gr', '45.00', '45.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (6, 'mt06', 'brisket', 'kg', 'kg', '35000.00', '35000.00', 1, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (7, 'mt07', 'chicken wing', 'pcs', 'pcs', '0.00', '0.00', 150, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (8, 'mt08', 'ayam pejantan', 'pcs', 'pcs', '10000.00', '10000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (9, 'mt09', 'sosis ayam champ', 'gr', 'gr', '45.00', '45.00', 2000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (10, 'mt10', 'sosis sapi champ', 'gr', 'gr', '45.00', '45.00', 2000, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (11, 'mt11', 'smoked beef', 'pcs', 'pcs', '10000.00', '10000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (12, 'mt12', 'sosis ayam endura', 'pcs', 'pcs', '5000.00', '5000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (13, 'mt13', 'sosis sapi endura', 'pcs', 'pcs', '5000.00', '5000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (14, 'bt01', 'kecap bango', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (15, 'bt02', 'saus tomat', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (16, 'bt03', 'saus sambal', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (17, 'bt04', 'minyak wijen', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (18, 'bt05', 'olive oil', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (19, 'bt06', 'saus tiram', 'gr', 'ge', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (20, 'bt07', 'l&p', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (21, 'bt08', 'kecap ikan', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (22, 'bt09', 'kecap inggris', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (23, 'bt10', 'red wine', '-', '-', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (24, 'bt11', 'white wine', '-', '-', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (25, 'bt12', 'kikoman', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (26, 'bt13', 'tobasco', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (27, 'bt14', 'tomato paste', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (28, 'bt15', 'cooking cream', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (29, 'bt16', 'cuka', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (30, 'bt17', 'sunquick orange', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (31, 'bt18', 'sunquick lemon', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (32, 'bt19', 'marjan strawberry', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (33, 'bt20', 'jamur kaleng', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (35, 'bt22', 'chicken knorr', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (36, 'bt23', 'maggie sapi', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (37, 'bt24', 'mustard', 'gr', 'gr', '200.00', '200.00', 2000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (38, 'ot01', 'tepung segitiga biru', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (39, 'ot02', 'tepung kanji', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (40, 'ot03', 'tepung roti', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (41, 'ot04', 'spagheti', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (42, 'ot05', 'butter', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (43, 'ot06', 'pengembang', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (44, 'ot07', 'mayonaise', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (45, 'ot08', 'mozarella', 'gr', 'gr', '95.00', '95.00', 6800, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (46, 'ot09', 'cheddar', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (47, 'ot10', 'parmesan', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (48, 're01', 'thyme', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (49, 're02', 'oregano', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (50, 're03', 'rosemary', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (51, 're04', 'bayleaves', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (52, 're05', 'chili powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (53, 're06', 'garlic powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (54, 're07', 'biji pala', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (55, 're08', 'biji lada hitam', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (56, 're09', 'onion powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (57, 're10', 'astaranis', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (58, 're11', 'kemiri', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (59, 're12', 'ketumbar', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (60, 're13', 'cengkeh', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (61, 're14', 'bawang goreng', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (62, 're15', 'paya', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (63, 're16', 'terasi', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (64, 're17', 'lada putih', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (65, 're18', 'garam', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (66, 're19', 'gula', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (67, 're20', 'merica', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (68, 're21', 'kapulaga', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (69, 'sy01', 'daun jeruk', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (70, 'sy02', 'daun bawang', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (71, 'sy03', 'seledri', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (72, 'sy04', 'salam', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (73, 'sy05', 'sereh', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (74, 'sy06', 'bawang merah', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (75, 'sy07', 'bawang bombay', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (77, 'sy08', 'bawang putih', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (78, 'sy09', 'lengkuas', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (79, 'sy10', 'jahe', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (80, 'sy11', 'kunyit', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (81, 'sy12', 'kencur', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (82, 'sy13', 'daun pisang', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (83, 'sy14', 'caisim', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '83', '31', '66', '', '', '', 50, 20, 10, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (84, 'sy15', 'jeruk nipis', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (85, 'sy16', 'tomat', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (86, 'sy17', 'timun', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (87, 'sy18', 'selada', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (88, 'sy19', 'wortel', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (89, 'sy20', 'bayam', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -100, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (90, 'sy21', 'cabe hijau', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (91, 'sy22', 'cabe merah', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (92, 'sy23', 'semangka', 'gr', 'gr', '250.00', '250.00', 2000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (93, 'sy24', 'melon', 'gr', 'gr', '250.00', '250.00', 2000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (94, 'sy25', 'alpukat', 'gr', 'gr', '300.00', '300.00', 2000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (95, 'sy26', 'apel', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (96, 'sy27', 'kiwi', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (97, 'sy28', 'anggur', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (98, 'sy29', 'tahu', 'pcs', 'pcs', '3000.00', '3000.00', 40, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (99, 'sy30', 'tempe', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (100, 'sy31', 'beras', 'gr', 'gr', '500.00', '500.00', 20000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (102, 'sy32', 'kentang', 'gr', 'gr', '40.00', '40.00', 2000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -160, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (103, 'mt01', 'sirloin australia', 'gr', 'gr', '31.00', '31.00', 5000, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -720, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (104, 'st01', 'imported us sirloin steak', 'pcs', 'pcs', '50000.00', '125000.00', 20000, 'no_image.jpg', 7, 1, '103', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (105, 'st02', 'imported tenderloin steak', 'pcs', 'pcs', '40000.00', '125000.00', 20000, 'no_image.jpg', 7, 1, '2', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (106, 'st03', 'chicken steak', 'pcs', 'pcs', '25000.00', '80000.00', 20000, 'no_image.jpg', 7, 1, '5', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (107, 'st04', 'potato wedges', 'pcs', 'pcs', '3200.00', '0.00', 20000, 'no_image.jpg', 7, 1, '118', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (108, 'st05', 'french fries', 'pcs', 'pcs', '2800.00', '0.00', 20000, 'no_image.jpg', 7, 1, '117', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (109, 'st06', 'mashed potato', 'pcs', 'pcs', '0.00', '0.00', 20000, 'no_image.jpg', 7, 0, '102', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (110, 'st07', 'bbq sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (111, 'st08', 'blackpepper sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (112, 'st09', 'seventhsin sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (113, 'st10', 'well done', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (114, 'st11', 'medium well', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (115, 'st12', 'medium', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (116, 'st13', 'imported back ribs', 'pcs', 'pcs', '50000.00', '150000.00', 0, 'no_image.jpg', 7, 1, '4', '89', '65', '55', '49', '18', 250, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (117, 'sy33', 'french fries bahan', 'gr', 'gr', '35.00', '35.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (118, 'sy34', 'wedges bahan', 'gr', 'gr', '40.00', '40.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (119, 'sn01', 'signature chicken wing', 'pcs', 'pcs', '15000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '7', '38', '120', '40', '52', '110', 3, 15, 1, 20, 3, 10, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (120, 'ot11', 'telur', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (121, 'sn02', 'omelette', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '120', '46', '65', '55', '117', '13', 2, 20, 5, 5, 80, 1, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (122, 'sn03', 'spicy tofu', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 3, '98', '90', '69', '77', '35', '', 2, 5, 5, 5, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (123, 'sn04', 'spicy cireng', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 3, '38', '39', '90', '77', '69', '35', 20, 20, 5, 5, 5, 20, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (124, 'sn05', 'onion ring', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 6, '41', '18', '90', '77', '35', '55', 120, 40, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 6, '41', '18', '90', '77', '35', '55', 120, 40, 5, 5, 10, 10, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (127, 'sn06', 'french fries with sausage', 'pcs', 'pcs', '20000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '117', '12', '13', '35', '52', '', 80, 1, 1, 10, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (128, 'ns01', 'nasi goreng bandung', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 2, '100', '120', '8', '21', '14', '75', 120, 2, 50, 10, 10, 20, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (129, 'ns02', 'sop buntut', 'pcs', 'pcs', '25000.00', '65000.00', 0, 'no_image.jpg', 7, 2, '3', '100', '84', '', '', '', 150, 120, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (130, 'ns03', 'sop buntut bakar', 'pcs', 'pcs', '25000.00', '70000.00', 0, 'no_image.jpg', 7, 2, '100', '3', '', '', '', '', 120, 150, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (131, 'ns04', 'sop buntut goreng', 'pcs', 'pcs', '25000.00', '70000.00', 0, 'no_image.jpg', 7, 2, '100', '3', '', '', '', '', 120, 150, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (132, 'ns05', 'ayam taliwang', 'pcs', 'pcs', '20000.00', '55000.00', 0, 'no_image.jpg', 7, 2, '8', '100', '98', '99', '133', '', 1, 120, 1, 1, 50, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (133, 'sy35', 'kangkung', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (134, 'ot12', 'dough', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (135, 'pz01', 'pizza meat lovers', 'pcs', 'pcs', '15000.00', '55000.00', 0, 'no_image.jpg', 7, 7, '134', '11', '9', '10', '45', '49', 1, 1, 60, 30, 60, 1, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (136, 'pz02', 'california pizza', 'pcs', 'pcs', '15000.00', '55000.00', 0, 'no_image.jpg', 7, 7, '134', '11', '10', '75', '49', '137', 1, 1, 30, 30, 1, 40, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (137, 'sy36', 'paprika', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (138, 'pz03', 'big cheese pizza', 'pcs', 'pcs', '20000.00', '60000.00', 0, 'no_image.jpg', 7, 7, '134', '46', '45', '47', '139', '', 1, 60, 60, 20, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (139, 'sy37', 'susu kental manis', 'gr', 'gr', '10000.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (140, 'pz04', 'nutella cheese pizza', 'pcs', 'pcs', '15000.00', '50000.00', 0, 'no_image.jpg', 7, 7, '134', '139', '45', '141', '', '', 1, 10, 60, 40, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (141, 'bt25', 'nutella', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (142, 'sl', 'fruit salad', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 8, '95', '96', '97', '', '', '', 1, 1, 6, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (143, 'sn07', 'extra french fries', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 3, '117', '35', '52', '', '', '', 160, 20, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (144, 'sn08', 'extra wedges potato', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '118', '35', '52', '', '', '', 160, 20, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (145, 'sn09', 'extra mashed potatoes', 'pcs', 'pcs', '5000.00', '15000.00', 0, 'no_image.jpg', 7, 3, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (146, 'sn10', 'extra bbq sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (147, 'sn11', 'extra black pepper sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (148, 'sn12', 'extra seventh sin sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (149, 'sn13', 'extra spinach', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (150, 'pz05', 'extra chesse', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (151, 'pz06', 'extra nutella cheese', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (152, 'ns06', 'nasi putih', 'pcs', 'pcs', '0.00', '8000.00', 0, 'no_image.jpg', 7, 2, '100', '', '', '', '', '', 120, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (153, 'es01', 'chocolate ice cream', 'gr', 'gr', '0.00', '10000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (154, 'es02', 'strawberry ice cream', 'gr', 'gr', '0.00', '10000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (155, 'es03', 'vanilla ice cream', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (156, 'jc01', 'avocado juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '94', '139', '66', '', '', '', 150, 20, 10, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (157, 'jc02', 'melon juice', '-', '', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '93', '66', '', '', '', '', 200, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (158, 'jc03', 'watermelon juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '92', '66', '', '', '', '', 200, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (159, 'jc04', 'orange juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '30', '66', '', '', '', '', 20, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (160, 'jc05', 'lemon juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '160', '66', '', '', '', '', 20, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (161, 'jc06', 'sawi juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (162, 'jc07', 'seledri juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '71', '31', '66', '', '', '', 30, 10, 10, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (163, 'jc08', 'ice cappucino', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, '164', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (164, 'bt26', 'capucino sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (165, 'jc09', 'teh tarik', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, '166', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (166, 'bt27', 'teh tarik sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (167, 'jc10', 'ice milo', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, '168', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (168, 'bt28', 'milo sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (169, 'jc11', 'ice lemon tea', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 8, 5, '170', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (170, 'bt29', 'lemon tea sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (171, 'jc12', 'strawberry milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '154', '139', '66', '', '', '', 50, 30, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (172, 'jc13', 'chocolate milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '153', '66', '139', '', '', '', 50, 20, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (173, 'jc14', 'vanilla milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '155', '66', '139', '', '', '', 50, 20, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (174, 'jc15', 'watermelon strawberry juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '92', '32', '', '', '', '', 200, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (175, 'jc16', 'coca cola', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (176, 'jc17', 'fanta', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (177, 'jc18', 'sprite', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (178, 'jc19', 'tea', 'pcs', 'pcs', '0.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (179, 'jc20', 'lemon squash', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (180, 'jc21', 'cola float', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (181, 'jc23', 'orange squash', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (182, 'jc24', 'fanta float', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (183, 'jc26', 'mineral water', 'pcs', 'pcs', '0.00', '5000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (184, 'ac01', 'anker stout 330ml', 'pcs', 'pcs', '20000.00', '40000.00', 72, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (185, 'ac02', 'bintang 330ml', 'pcs', 'pcs', '14000.00', '25000.00', 120, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (186, 'ac03', 'bintang radler lemon', 'pcs', 'pcs', '14000.00', '25000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (187, 'ac04', 'bintang radler grape fruit', 'psc', 'pcs', '14000.00', '25000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (188, 'ac05', 'carlsberg 330ml', 'pcs', 'pcs', '17500.00', '35000.00', 48, 'no_image.jpg', 8, 4, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (189, 'ac06', 'guiness 330ml', 'pcs', 'pcs', '21000.00', '40000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (190, 'ac07', 'heineken 330ml', 'pcs', 'pcs', '19000.00', '35000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (191, 'ac08', 'heineken light 330ml', 'pcs', 'pcs', '19000.00', '35000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (192, 'ac09', 'anker 620ml', 'pcs', 'psc', '25000.00', '50000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (193, 'ac10', 'bintang 620ml', 'pcs', 'pcs', '25000.00', '50000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (194, 'ac11', 'guiness 620ml', 'pcs', 'pcs', '34000.00', '60000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (195, 'ac12', 'heineken 620ml', 'psc', 'pcs', '34000.00', '60000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  `inv_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (1, 1, 101, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (2, 2, 101, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (3, 3, 104, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '130000.00', '130000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (4, 4, 104, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '130000.00', '130000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (5, 5, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (6, 6, 146, 'sn10', 'extra bbq sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (7, 7, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (8, 8, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (9, 9, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (10, 10, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (11, 11, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (12, 12, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (13, 13, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `pos` tinyint(4) NOT NULL DEFAULT '0',
  `paid` decimal(25,2) DEFAULT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_holder` varchar(100) DEFAULT NULL,
  `cheque_no` varchar(20) DEFAULT NULL,
  `noMeja` varchar(25) NOT NULL,
  `pelayan` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (1, 'SL-0001', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '125000.00', '0.00', '125000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '125000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (2, 'SL-0002', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '125000.00', '0.00', '125000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '125000.00', '', '', '', '13', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (3, 'SL-0003', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '130000.00', '0.00', '130000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '150000.00', '', '', '', '1', 'Owner');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (4, 'SL-0004', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '130000.00', '0.00', '130000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '150000.00', '', '', '', '2', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (5, 'SL-0005', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '3', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (6, 'SL-0006', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (7, 'SL-0007', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (8, 'SL-0008', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '1', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (9, 'SL-0009', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (10, 'SL-0010', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (11, 'SL-0011', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (12, 'SL-0012', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '100000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (13, 'SL-0013', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '100000.00', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '2.3',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `restrict_sale` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_user` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_calendar` tinyint(4) NOT NULL DEFAULT '0',
  `bstatesave` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`, `restrict_sale`, `restrict_user`, `restrict_calendar`, `bstatesave`) VALUES (1, 'seventhsin_2001.png', 'login_logo.png', 'SEVENTHSIN', 'arabic', 1, 'RP.', 2, 1, 50, 9, 30, '2.3', 1, 5, 'SL', 'QU', 'PO', 'TR', 'code128', 'cosmo', 1, 1, 2, 2, 1, 1, 0, 0, 0, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (1, 7, 'mm01', 'steik');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (2, 7, 'mm02', 'nasi');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (3, 7, 'mm03', 'snack');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (4, 8, 'mn01', 'alcohol');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (5, 8, 'mn02', 'non alcohol');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (6, 7, 'mm04', 'spaghetti');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (7, 7, 'mm05', 'pizza');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (8, 7, 'mm06', 'salad');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, '10%', '10.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `tax_val` decimal(25,2) DEFAULT NULL,
  `unit_price` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) DEFAULT NULL,
  `tr_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'owner', '92bebcbea72ab95e402191a132947a1800d973b0', NULL, 'owner@seventhsin.com', NULL, NULL, NULL, 'dec3b7325cb8ce7662774167b86bf65f3915aa08', 1351661704, 1507884847, 1, 'Owner', 'Owner', 'Stock Manager', '0105292122');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (2, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'kasir kasir', '14b15286a09f294628547606a91d138867f3351a', NULL, 'yannri.zenner@gamantha.com', NULL, NULL, NULL, NULL, 1471921682, 1475808726, 1, 'kasir', 'kasir', 'gamantha', '1212312312312');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (3, '��	', 'kasir kasir1', '0955437a010c2d76618deb0bcd0fb5362f17bdd6', NULL, 'kasir@seventhsin.com', NULL, NULL, NULL, NULL, 1506839680, 1507881801, 1, 'kasir', 'kasir', 'seventhsin', '123456789789');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (4, '��', 'zenner zee', 'e1993c5256e43d0321e1af9ef6b4ca139a8fe3b5', NULL, 'pembelian@seventhsin.com', NULL, NULL, NULL, NULL, 1506850992, 1506851019, 1, 'zenner', 'zee', 'seventhsin', '3454657889900');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (2, 2, 4);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (3, 3, 4);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (4, 4, 2);


#
# TABLE STRUCTURE FOR: waiters
#

DROP TABLE IF EXISTS waiters;

CREATE TABLE `waiters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `kontak` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (1, 'Waiter1', 'Alamat Waiter1', 'Kontak Waiter1');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (2, 'Waiter2', 'Alamat Waiter2', 'Kontak Waiter2 ');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (3, 'Waiter3', 'Alamat Waiter3', 'Kontak Waiter3');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (4, 'Waiter4', 'Alamat Waiter4', 'Kontak Waiter4');


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (1, 'gd01', 'gudang inventory', '.\r\n', 'Palu');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (2, 'gd02', 'dapur', 'Yos Sudarso', 'Palu');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (3, 'gd03', 'bar', 'Yos Sudarso', 'Palu');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (28, 16, 2, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (29, 57, 1, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (30, 18, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (32, 104, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (33, 147, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (34, 146, 2, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (35, 183, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (36, 132, 1, -2);


