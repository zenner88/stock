#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'MEGAWATI', 'Tecdiary IT Solutions', 'Address', 'City', 'Sate', '0000', 'INDONESIA', '012345678', 'saleem@tecdairy.com', 'logo.png', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: bom
#

DROP TABLE IF EXISTS bom;

CREATE TABLE `bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(50) NOT NULL,
  `idBahanBaku` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduk` (`idProduk`),
  KEY `idBahanBaku` (`idBahanBaku`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (52, 'Test005', 'PK-02', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (53, 'Test005', 'PR-001', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (54, 'Test005', 'PR-013', 11);


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (2, '001', 'besi');
INSERT INTO categories (`id`, `code`, `name`) VALUES (3, '002', 'cat tembok');
INSERT INTO categories (`id`, `code`, `name`) VALUES (4, '003', 'dempul');
INSERT INTO categories (`id`, `code`, `name`) VALUES (5, '004', 'gembok');
INSERT INTO categories (`id`, `code`, `name`) VALUES (6, '005', 'keramik');
INSERT INTO categories (`id`, `code`, `name`) VALUES (7, 'MAIN-01', 'Menu Utama');
INSERT INTO categories (`id`, `code`, `name`) VALUES (8, 'DRINK-01', 'minuman');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');
INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'SANGGAR INDAH', 'Customer Company Name', 'SUKAHAJI', 'BANDUNG', 'JAWA BARAT', '40152', 'INDONESIA', '0123456789', 'customer@tecdiary.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'Zenner', 'zenner ABC', 'Jl. Cikawao, Kav. C14 No.34 Bandung', 'BANDUNG', 'JAWA BARAT', '40151', 'INDONESIA', '0851515151', 'zenner88@gmail.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO damage_products (`id`, `date`, `product_id`, `quantity`, `warehouse_id`, `note`, `user`, `updated_by`) VALUES (1, '2016-10-07', 26, 4, 1, '&lt;p&gt;\n   Pecah saat pengiriman\n&lt;/p&gt;', 'Owner Owner', NULL);


#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yyyy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yyyy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO deliveries (`id`, `date`, `time`, `reference_no`, `customer`, `address`, `note`, `user`, `updated_by`) VALUES (2, '2016-10-07', '12:45 PM', 'SL-0012', 'SANGGAR INDAH', 'SUKAHAJI BANDUNG JAWA BARAT 40152 INDONESIA. \nTel: 0123456789', '&lt;p&gt;\n Penerima Bapak. Gungun\n&lt;/p&gt;', 'kasir kasir', NULL);


#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS log;

CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(25) NOT NULL,
  `qty` int(11) NOT NULL,
  `namaTransaksi` varchar(100) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (28, 'PK-02', 10, 'Pengurangan Data Produk (Penjualan)', '2017-09-30 05:21:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (29, 'PR-001', 10, 'Pengurangan Data Produk (Penjualan)', '2017-09-30 05:21:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (30, 'PR-013', 11, 'Pengurangan Data Produk (Penjualan)', '2017-09-30 05:21:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (31, 'Test005', 1, 'Penjualan Produk', '2017-09-30 05:21:24');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS menu;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `ext_1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 7, 1, 1, 'yes', '', '', '', '');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `size` varchar(55) NOT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  `jml_cf1` int(11) NOT NULL,
  `jml_cf2` int(11) NOT NULL,
  `jml_cf3` int(11) NOT NULL,
  `jml_cf4` int(11) NOT NULL,
  `jml_cf5` int(11) NOT NULL,
  `jml_cf6` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `track_quantity` tinyint(4) DEFAULT '1',
  `details` varchar(1000) DEFAULT NULL,
  `menu` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (5, 'PK-02', 'ASDA', 'BH', '30MM', '3000.00', '9000.00', 5, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 90, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (6, 'PR-001', 'BESI BETON ULIR 13 MM', 'BTG', '13MM', '50000.00', '60000.00', 5, 'no_image.jpg', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 90, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (7, 'PR-002', 'BESI BETON 10 MM', 'BTG', '10MM', '30000.00', '36000.00', 5, 'no_image.jpg', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (8, 'PR-003', 'BESI BETON 6 MM', 'BTG', '6MM', '20000.00', '24000.00', 5, 'no_image.jpg', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 12, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (9, 'PR-004', 'BESI BETON 8 MM', 'BTG', '8MM', '35000.00', '42000.00', 5, 'no_image.jpg', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 12, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (10, 'PR-005', 'BESI BESI HOLLOW', 'BTG', '2X4M', '100000.00', '120000.00', 5, 'no_image.jpg', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (11, 'PR-006', 'CAT AVIAN PUTIH', 'KLG', '1L', '100000.00', '120000.00', 5, 'cat-kayu-besi-avian-305-leather.jpg', 3, 0, '8', '', '', '', '', '', 3, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (12, 'PR-007', 'CAT NIPPE ABU SURFACER', 'KLG', '5L', '120000.00', '144000.00', 5, '6435cf505_52.png', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (13, 'PR-008', 'CAT SANLEX WIND WHITE', 'KLG', '5L', '90000.00', '108000.00', 5, 'CFQNJMrWEAAC7Zh.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (14, 'PR-009', 'CAT VINILEX 242', 'KLG', '5L', '95000.00', '114000.00', 5, 'vinilex.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (15, 'PR-010', 'CAT TEMBOK MATEK', 'KLG', '5L', '70000.00', '84000.00', 5, 'ad26edabb_21.png', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (16, 'PR-011', 'DEMPUL DAIWA', 'KLG', '', '45000.00', '54000.00', 5, 'no_image.jpg', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (17, 'PR-012', 'DEMPUL ISAMU ABU', 'KLG', '', '47500.00', '57000.00', 5, 'no_image.jpg', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (18, 'PR-013', 'DEMPUL ISAMU PUTIH', 'KLG', '', '45000.00', '54000.00', 5, 'no_image.jpg', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 89, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (19, 'PR-014', 'DEMPUL SANPOLAX', 'KLG', '', '50000.00', '60000.00', 5, 'no_image.jpg', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (20, 'PR-015', 'DEMPUL SANSIRO', 'KLG', '', '65000.00', '78000.00', 5, 'no_image.jpg', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 70, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (21, 'PR-016', 'GEMBOK KL 40MM', 'BH', '', '46500.00', '55800.00', 5, 'no_image.jpg', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (22, 'PR-017', 'GEMBOK MOUNTERY 50MM', 'BH', '', '55000.00', '66000.00', 5, 'no_image.jpg', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 1, 1, NULL, 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (23, 'PR-018', 'GEMBOK STENLES 50MM', 'BH', '', '70000.00', '84000.00', 5, '40mm-Heavy-Duty-Solid-Lock-Door-Gate-Box-Safety-Stainless-Steel-Padlock-Gold-Tone-4-Keys1.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (24, 'PR-019', 'GEMBOK STENLES HSS 40MM', 'BH', '', '55000.00', '66000.00', 5, '40mm-Heavy-Duty-Solid-Lock-Door-Gate-Box-Safety-Stainless-Steel-Padlock-Gold-Tone-4-Keys.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (25, 'PR-020', 'GEMBOK GOLD DOOR 30ML', 'BH', '', '75000.00', '90000.00', 5, 'Home-Cabinet-Door-Mini-Metal-font-b-Padlock-b-font-Gold-Tone-w-font-b-Keys.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (26, 'PR-021', 'KERAMIK ANTALIA GREEN', 'DUS', '20/20', '70000.00', '96000.00', 5, 'Keramik-Lantai-Kamar-Mandi-Miami-Green-20x20.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (27, 'PR-022', 'KERAMIK ASITILE BLACK', 'DUS', '20/20', '85000.00', '102000.00', 5, 'index.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (28, 'PR-023', 'KERAMIK MULIA WHITE', 'DUS', '30/30', '100000.00', '120000.00', 5, 'Keramik-Lantai-Mulia-Putih-Polos-40x402.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (29, 'PR-024', 'KERAMIK IKAD CITY GLOSY WHITE', 'DUS', '20/20', '85000.00', '102000.00', 5, 'Keramik-Lantai-Mulia-Putih-Polos-40x401.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 20, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (30, 'PR-025', 'KERAMIK NUSANTARA PUTIH', 'DUS', '30/30', '65000.00', '78000.00', 5, 'Keramik-Lantai-Mulia-Putih-Polos-40x40.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (31, 'PR-01', 'Nasi Goreng Special', 'Piring', '', '5000.00', '15000.00', 0, 'no_image.jpg', 7, 1, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 5, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (32, 'RST-02', 'Capucino', 'gelas', '', '2000.00', '8000.00', 0, 'no_image.jpg', 8, 3, '8', '11', '', '', '', '', 1, 2, 0, 0, 0, 0, -1, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (33, '099', 'Food 1', '100', '', '2000.00', '2000.00', 0, 'no_image.jpg', 8, 3, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -11, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (34, 'MG-01', 'Mie GOreng', 'piring', '1', '9000.00', '15000.00', 100, 'no_image.jpg', 7, 1, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (35, 'MK-02', 'Mie Kuah', 'Piring', '1', '9000.00', '15000.00', 100, 'no_image.jpg', 7, 1, '10', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '0', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (36, '91', 'Seblak', 'piring', '1', '5000.00', '10000.00', 100, 'no_image.jpg', 7, 1, '6', '7', '7', '11', '10', '16', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (37, '99', 'Lotek', 'piring', '1', '8000.00', '20000.00', 100, 'no_image.jpg', 7, 1, '6', '8', '24', '12', '31', '30', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (38, '990', 'Lotek', 'piring', '1', '8000.00', '20000.00', 100, 'no_image.jpg', 7, 0, '6', '8', '24', '12', '31', '30', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (39, '88', 'akjsdkj', 'piring', '1', '9000.00', '15000.00', 100, 'no_image.jpg', 3, 0, '6', '9', '9', '14', '34', '32', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (40, '1111', 'waw', 'piring', '1', '9000.00', '10000.00', 100, 'no_image.jpg', 7, 5, '5', '6', '7', '8', '9', '10', 2, 2, 5, 2, 2, 3, 6, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (41, '9902', 'Bubur', 'piring', '1', '9000.00', '10000.00', 100, 'no_image.jpg', 3, 0, '11', '9', '', '', '', '', 3, 2, 0, 0, 0, 0, -1, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (42, '2hjkhjkjh', 'jhajhsaj', 'piring', '11', '111111.00', '1111.00', 111, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 3, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (43, 'sdsd', 'ccsc', 'piring', '', '787878.00', '787.00', 22, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 3, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (44, 'asbaas', '111', '111', '', '11111.00', '111.00', 11, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 2, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (45, 'KI009', 'Baso', 'Mangkot', '', '20000.00', '2000.00', 90, 'no_image.jpg', 7, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 3, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (46, 'LOB1', 'sa', 'piring', '', '20000.00', '200.00', 90, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 3, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (47, 'jksjk', 'jhjh', 'piring', '', '90.00', '9.00', 90, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (48, 'jsss', 'jsjsjs', 'piring', '', '111.00', '11.00', 11, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 3, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (49, '9098', 'hkjhh', '22', '1', '223322.00', '222.00', 11, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 2, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (50, '22221', 'cccc', 'jhhjhs', '', '21212.00', '111.00', 111, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (51, 'oidoido', 'dkjnsjnds', '21', '222', '33232.00', '121.00', 1, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (52, 'Test001', 'Test001', 'Test1', '', '10000.00', '10000.00', 11, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (53, 'Test002', 'Test002', 'Test002', '', '22222.00', '22.00', 22, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 2, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (54, 'HQ0SDGQHTT', 'HQ0SDGQHTT', 'piring', '', '10000.00', '1000.00', 100, 'no_image.jpg', 7, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 2, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (55, 'Test004', 'Test004', 'Piring', '', '10000.00', '1000.00', 100, 'no_image.jpg', 7, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (56, 'Test005', 'Test005', 'Mangkok', '', '10000.00', '1000.00', 10, 'no_image.jpg', 7, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (6, 6, 26, 'PR-021', 'KERAMIK ANTALIA GREEN', 200, '70000.00', NULL, '14000000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (7, 7, 11, 'PR-006', 'CAT AVIAN PUTIH', 50, '100000.00', NULL, '5000000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (9, 8, 11, 'PR-006', 'CAT AVIAN PUTIH', 1, '100000.00', NULL, '90000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (10, 9, 11, 'PR-006', 'CAT AVIAN PUTIH', 1, '100000.00', NULL, '100000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (11, 10, 11, 'PR-006', 'CAT AVIAN PUTIH', 0, '100000.00', NULL, '10000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (12, 11, 31, 'PR-01', 'Nasi Goreng Special', 5, '5000.00', NULL, '25000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (13, 11, 5, 'PK-02', 'ASDA', 5, '3000.00', NULL, '15000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (14, 12, 31, 'PR-01', 'Nasi Goreng Special', 2, '5000.00', NULL, '10000.00', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  `inv_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (6, 'PO-0001', 1, 2, 'MAKMUR SENTOSA CV', '2016-10-07', '&lt;p&gt;\n CATATAN PEMBELIAN\n&lt;/p&gt;', '14000000.00', 'Owner Owner', NULL, '0.00', '14000000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (7, 'PO-0007', 1, 2, 'MAKMUR SENTOSA CV', '2016-10-07', '', '5000000.00', 'Owner Owner', NULL, '0.00', '5000000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (8, 'PO-0008', 1, 2, 'MAKMUR SENTOSA CV', '2017-05-08', '', '90000.00', 'Owner Owner', 'Owner Owner', '0.00', '90000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (9, 'PO-0009', 1, 2, 'MAKMUR SENTOSA CV', '2017-05-08', '', '100000.00', 'Owner Owner', NULL, '0.00', '100000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (10, 'PO-0010', 1, 2, 'MAKMUR SENTOSA CV', '2017-05-08', '', '10000.00', 'Owner Owner', NULL, '0.00', '10000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (11, 'PO-0011', 2, 3, 'Gudang Bahan Baku', '2017-05-13', '', '40000.00', 'Owner Owner', NULL, '0.00', '40000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (12, 'menu-01', 2, 3, 'Gudang Bahan Baku', '2017-05-13', 'bla', '10000.00', 'Owner Owner', NULL, '0.00', '10000.00');


#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO quote_items (`id`, `quote_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount_id`, `discount`) VALUES (2, 2, 26, 'PR-021', 'KERAMIK ANTALIA GREEN', 'DUS', 1, '0.00', 10, '96000.00', '960000.00', '0.00', NULL, '0.00', 1, '0.00');


#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO quotes (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `user`, `updated_by`, `inv_discount`, `discount_id`, `shipping`) VALUES (2, 'QU-0001', 1, 1, 'MEGAWATI', 2, 'Zenner', '2016-10-07', '', '', '960000.00', '0.00', '960000.00', NULL, NULL, '0.00', 1, 'Owner Owner', NULL, '0.00', 0, '0.00');


#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (11, 11, 11, 'PR-006', 'CAT AVIAN PUTIH', 'KLG', 1, '0.00', 1, '120000.00', '120000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (12, 12, 26, 'PR-021', 'KERAMIK ANTALIA GREEN', 'DUS', 1, '0.00', 10, '96000.00', '960000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (13, 13, 26, 'PR-021', 'KERAMIK ANTALIA GREEN', 'DUS', 1, '0.00', 10, '96000.00', '960000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (14, 14, 32, 'RST-02', 'Capucino', 'gelas', 1, '0.00', 1, '8000.00', '8000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (15, 15, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (16, 15, 33, '099', 'Food 1', '100', 1, '0.00', 1, '2000.00', '2000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (17, 16, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (18, 16, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (19, 16, 41, '9902', 'Bubur', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (20, 17, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (21, 18, 40, '1111', 'waw', 'piring', 1, '0.00', 8, '10000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (22, 19, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (23, 20, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (24, 21, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (25, 22, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (26, 23, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (27, 24, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (28, 25, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (29, 26, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (30, 27, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (31, 28, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (32, 29, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (33, 30, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (34, 31, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (35, 32, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (36, 33, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (37, 34, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (38, 35, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (39, 36, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (40, 37, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (41, 38, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (42, 39, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (43, 42, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (44, 43, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (45, 44, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (46, 45, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (47, 46, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (48, 47, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (49, 48, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (50, 49, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (51, 50, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (52, 51, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (53, 52, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (54, 59, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (55, 60, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (56, 61, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (57, 62, 40, '1111', 'waw', 'piring', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (58, 62, 45, 'KI009', 'Baso', 'Mangkot', 3, '6.00%', 1, '2000.00', '2000.00', '120.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (59, 63, 45, 'KI009', 'Baso', 'Mangkot', 3, '6.00%', 1, '2000.00', '2000.00', '120.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (60, 64, 45, 'KI009', 'Baso', 'Mangkot', 3, '6.00%', 1, '2000.00', '2000.00', '120.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (61, 65, 45, 'KI009', 'Baso', 'Mangkot', 3, '6.00%', 2, '2000.00', '4000.00', '240.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (62, 65, 40, '1111', 'waw', 'piring', 1, '0.00', 2, '10000.00', '20000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (63, 66, 56, 'Test005', 'Test005', 'Mangkok', 1, '0.00', 2, '1000.00', '2000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (64, 67, 56, 'Test005', 'Test005', 'Mangkok', 1, '0.00', 2, '1000.00', '2000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (65, 68, 56, 'Test005', 'Test005', 'Mangkok', 1, '0.00', 1, '1000.00', '1000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (66, 69, 56, 'Test005', 'Test005', 'Mangkok', 1, '0.00', 1, '1000.00', '1000.00', '0.00', '', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `pos` tinyint(4) NOT NULL DEFAULT '0',
  `paid` decimal(25,2) DEFAULT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_holder` varchar(100) DEFAULT NULL,
  `cheque_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (11, 'SL-0001', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2016-10-07', NULL, NULL, '120000.00', '0.00', '120000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '120000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (12, 'SL-0012', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2016-10-07', '', '', '960000.00', '0.00', '960000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', NULL, '0.00', 0, NULL, NULL, NULL, NULL);
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (13, 'SL-0013', 1, 1, 'MEGAWATI', 2, 'Zenner', '2016-10-07', '', '', '960000.00', '0.00', '960000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', NULL, '0.00', 0, NULL, NULL, NULL, NULL);
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (14, 'SL-0014', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-05-13', NULL, NULL, '8000.00', '0.00', '8000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (15, 'SL-0015', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-26', NULL, NULL, '22000.00', '0.00', '22000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '22222.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (16, 'SL-0016', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-26', NULL, NULL, '30000.00', '0.00', '30000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '30000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (17, 'SL-0017', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (18, 'SL-0018', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '80000.00', '0.00', '80000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 8, '0.00', 1, '80000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (19, 'SL-0019', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (20, 'SL-0020', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (21, 'SL-0021', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (22, 'SL-0022', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (23, 'SL-0023', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (24, 'SL-0024', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (25, 'SL-0025', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (26, 'SL-0026', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (27, 'SL-0027', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (28, 'SL-0028', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (29, 'SL-0029', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (30, 'SL-0030', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (31, 'SL-0031', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (32, 'SL-0032', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (33, 'SL-0033', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (34, 'SL-0034', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-27', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (35, 'SL-0035', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (36, 'SL-0036', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (37, 'SL-0037', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (38, 'SL-0038', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (39, 'SL-0039', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (40, 'SL-0040', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (41, 'SL-0041', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (42, 'SL-0042', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (43, 'SL-0043', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (44, 'SL-0044', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (45, 'SL-0045', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (46, 'SL-0046', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (47, 'SL-0047', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (48, 'SL-0048', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (49, 'SL-0049', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (50, 'SL-0050', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (51, 'SL-0051', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (52, 'SL-0052', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (53, 'SL-0053', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (54, 'SL-0054', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (55, 'SL-0055', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (56, 'SL-0056', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (57, 'SL-0057', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (58, 'SL-0058', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (59, 'SL-0059', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (60, 'SL-0060', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-28', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (61, 'SL-0061', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-29', NULL, NULL, '20000.00', '0.00', '20000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '20000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (62, 'SL-0062', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-29', NULL, NULL, '12000.00', '120.00', '12120.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '12120.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (63, 'SL-0063', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-29', NULL, NULL, '2000.00', '120.00', '2120.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '2120.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (64, 'SL-0064', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '2000.00', '120.00', '2120.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '2120.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (65, 'SL-0065', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '24000.00', '240.00', '24240.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '24240.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (66, 'SL-0066', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '2000.00', '0.00', '2000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '2000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (67, 'SL-0067', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '2000.00', '0.00', '2000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '2000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (68, 'SL-0068', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '1000.00', '0.00', '1000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '1000.00', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (69, 'SL-0069', 1, 1, 'MEGAWATI', 1, 'SANGGAR INDAH', '2017-09-30', NULL, NULL, '1000.00', '0.00', '1000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '1000.00', '', '', '');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '2.3',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `restrict_sale` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_user` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_calendar` tinyint(4) NOT NULL DEFAULT '0',
  `bstatesave` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`, `restrict_sale`, `restrict_user`, `restrict_calendar`, `bstatesave`) VALUES (1, 'header_logo.png', 'login_logo.png', 'Gamantha Stock Manager', 'arabic', 1, 'RP.', 2, 1, 100, 9, 30, '2.3', 1, 5, 'SL', 'QU', 'PO', 'TR', 'code128', 'cosmo', 1, 1, 2, 2, 1, 1, 0, 0, 0, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (1, 7, 'NS-01', 'nasi');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (2, 7, 'NS-02', 'sayur');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (3, 8, 'DR-01', 'kopi');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (4, 8, 'DR-02', 'jus');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'SUBUR JAYA PT', 'Supplier Company Name', 'Supplier Address', 'Petaling Jaya', 'Selangor', '46050', 'Malaysia', '0123456789', 'supplier@tecdiary.com', '-', '-', '-', '-', '-', '-');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'MAKMUR SENTOSA CV', 'CV MAKMUR SENTOSA', 'SARIJADI', 'BANDUNG', 'JAWA BARAT ', '40151', 'INDONESIA', '0222929292', 'hello.sosiohub@gmail.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (3, 'Gudang Bahan Baku', 'Gudang Cafe', 'Bandung', 'Bandung', 'Jabar', '90876', 'Indo', '0987865578', 'gudang@gmail.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO suspended_bills (`id`, `date`, `customer_id`, `count`, `tax1`, `tax2`, `discount`, `inv_total`, `total`) VALUES (1, '2017-09-24', 1, 1, '0.00', '0.00', '0.00', '120000.00', '120000.00');


#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO suspended_items (`id`, `suspend_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `discount`, `discount_id`, `discount_val`, `serial_no`) VALUES (1, 1, 11, 'PR-006', 'CAT AVIAN PUTIH', 'KLG', 1, '0.00', 1, '120000.00', '120000.00', '0.00', '0.00', 1, '0.00', '');


#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, 'GST', '6.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `tax_val` decimal(25,2) DEFAULT NULL,
  `unit_price` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) DEFAULT NULL,
  `tr_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'owner', '54af4ba64ec0a86f4f3e1e45159df08902ab8f40', NULL, 'owner@tecdiary.com', NULL, NULL, NULL, '6d51ca3212f297271477fb4f3ec312d68dfd1702', 1351661704, 1506681030, 1, 'Owner', 'Owner', 'Stock Manager', '0105292122');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (2, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'kasir kasir', '14b15286a09f294628547606a91d138867f3351a', NULL, 'yannri.zenner@gamantha.com', NULL, NULL, NULL, NULL, 1471921682, 1475808726, 1, 'kasir', 'kasir', 'gamantha', '1212312312312');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (2, 2, 4);


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (1, 'WHI', 'Warehouse 1', 'Address', 'City');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (2, 'RST-01', 'RESTO ONE', 'Jl. Jalan', 'Bandung');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (3, 26, 1, 176);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (4, 11, 1, 51);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (5, 31, 2, 5);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (6, 5, 2, 5);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (7, 31, 2, 2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (8, 32, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (9, 40, 1, -67);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (10, 33, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (11, 41, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (12, 45, 1, -5);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (13, 56, 1, -6);


