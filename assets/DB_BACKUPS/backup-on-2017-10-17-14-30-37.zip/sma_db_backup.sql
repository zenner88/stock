#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'HARUN', 'SEVENTHSIN', 'YOS SUDARSO 8-9', 'PALU', 'SULTENG', '-', 'INDONESIA', '012345678', 'harun@seventhsin.com', 'logo.png', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: bom
#

DROP TABLE IF EXISTS bom;

CREATE TABLE `bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(50) NOT NULL,
  `idBahanBaku` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduk` (`idProduk`),
  KEY `idBahanBaku` (`idBahanBaku`)
) ENGINE=InnoDB AUTO_INCREMENT=597 DEFAULT CHARSET=latin1;

INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (1, 'mt02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (2, 'mt03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (4, 'mt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (5, 'mt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (6, 'mt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (7, 'mt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (8, 'mt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (9, 'mt08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (10, 'mt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (11, 'mt10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (12, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (13, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (14, 'mt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (15, 'mt12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (16, 'mt13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (17, 'bt01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (18, 'bt01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (19, 'bt02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (20, 'bt03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (21, 'bt04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (22, 'bt05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (23, 'bt06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (24, 'bt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (25, 'bt07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (26, 'bt08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (27, 'bt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (28, 'bt09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (29, 'bt10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (30, 'bt11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (31, 'bt12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (32, 'bt13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (33, 'bt14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (34, 'bt15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (35, 'bt16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (36, 'bt17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (37, 'bt18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (38, 'bt19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (39, 'bt20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (40, 'bt21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (41, 'bt22', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (42, 'bt23', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (43, 'bt24', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (44, 'ot01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (45, 'ot02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (46, 'ot03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (47, 'ot04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (48, 'ot05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (49, 'ot06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (50, 'ot07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (51, 'ot08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (52, 'ot09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (53, 'ot10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (54, 're01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (55, 're02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (56, 're03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (57, 're04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (58, 're05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (59, 're06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (60, 're07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (61, 're08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (62, 're09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (63, 're10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (64, 're11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (65, 're12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (66, 're13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (67, 're14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (68, 're15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (69, 're16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (70, 're17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (71, 're18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (72, 're19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (73, 're20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (74, 're21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (75, 'sy01', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (76, 'sy02', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (77, 'sy03', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (78, 'sy04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (79, 'sy05', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (80, 'sy06', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (81, 'sy07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (82, 'sy07', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (83, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (84, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (85, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (86, 'sy08', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (87, 'sy09', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (88, 'sy10', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (89, 'sy11', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (90, 'sy12', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (91, 'sy13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (92, 'sy13', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (93, 'sy14', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (95, 'sy16', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (96, 'sy17', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (97, 'sy18', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (98, 'sy19', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (99, 'sy20', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (100, 'sy21', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (101, 'sy22', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (102, 'sy23', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (103, 'sy24', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (104, 'sy25', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (105, 'sy26', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (106, 'sy26', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (107, 'sy27', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (108, 'sy27', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (109, 'sy28', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (110, 'sy29', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (111, 'sy30', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (112, 'sy30', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (113, 'sy31', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (117, 'sy32', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (118, 'mt01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (143, 'st07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (144, 'st08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (146, 'st10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (147, 'st11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (148, 'st12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (150, 'sy33', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (151, 'sy34', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (153, 'ot11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (160, 'sp01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (161, 'sp02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (163, 'ns01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (167, 'ns05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (168, 'sy35', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (169, 'ot12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (172, 'sy36', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (174, 'sy37', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (176, 'bt25', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (181, 'sn10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (182, 'sn10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (183, 'sn11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (188, 'pz06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (189, 'ns06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (195, 'jc02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (196, 'jc03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (197, 'jc04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (198, 'jc05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (202, 'bt26', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (204, 'bt27', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (206, 'bt28', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (208, 'bt29', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (209, 'jc12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (210, 'jc13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (211, 'jc14', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (218, 'jc20', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (220, 'jc23', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (221, 'jc24', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (223, 'ac01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (224, 'ac01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (228, 'ac05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (229, 'ac06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (230, 'ac07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (231, 'ac08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (232, 'ac09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (233, 'ac10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (234, 'ac11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (235, 'ac12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (236, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (237, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (238, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (239, 'pz04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (243, 'jc26', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (244, 'jc26', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (272, 'jc21', 'jc16', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (298, 'jc18', 'jc18', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (299, 'jc18', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (300, 'jc18', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (301, 'jc17', 'jc17', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (306, 'ac17', 'ac17', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (307, 'jc16', 'jc16', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (308, 'jc16', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (309, 'jc16', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (310, 'jc16', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (311, 'ac16', 'ac16', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (312, 'ac15', 'ac15', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (314, 'ac13', 'ac13', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (315, 'ac13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (322, 'sy20', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (323, 'sy20', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (331, 're18', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (350, 're22', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (366, 'sy32', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (386, 'st13', 'st13', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (387, 'st13', 're18', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (388, 'st13', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (389, 'st13', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (390, 'st13', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (391, 'mt04', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (392, 'sn02', 'ot11', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (393, 'sn02', 'ot09', 30);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (394, 'sn02', 'sy32', 80);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (395, 'sn02', 'mt10', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (396, 'sn02', 'bt22', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (397, 'sn02', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (408, 'bt30', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (434, 'sy15', 'mt01', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (435, 'sy15', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (452, 'sn03', 'sy29', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (453, 'sn03', 'bt22', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (454, 'sn03', 'sy22', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (455, 'sn03', 'sy01', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (456, 'sn03', 'sy08', 3);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (457, 'sn03', 're22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (472, 'st05', 'sy33', 80);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (473, 'st05', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (474, 'st05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (475, 'st04', 'sy34', 80);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (476, 'st04', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (477, 'st04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (478, 'sn08', 'sy34', 160);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (479, 'sn08', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (480, 'st06', 'sy32', 75);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (481, 'st06', 'bt30', 20);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (482, 'st06', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (483, 'st06', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (484, 'st06', 're07', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (485, 'st06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (499, 'sn01', 'mt07', 3);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (500, 'sn01', 'bt22', 3);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (501, 'sn01', 're08', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (502, 'sn01', 're22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (503, 'sn04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (504, 'sn04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (505, 'sn05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (506, 'sn05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (507, 'st02', 'mt02', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (508, 'st02', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (509, 'st02', 're18', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (510, 'st02', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (511, 'st02', 're02', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (512, 'st02', 'bt05', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (513, 'st02', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (514, 'st02', 're22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (515, 'st02', 're03', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (516, 'st01', 'mt01', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (517, 'st01', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (518, 'st01', 're02', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (519, 'st01', 'bt05', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (520, 'st01', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (521, 'st01', 're18', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (522, 'st01', 're03', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (523, 'st01', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (524, 'st01', 're22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (525, 'st03', 'mt05', 180);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (526, 'st03', 'sy20', 50);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (527, 'st03', 're22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (528, 'st03', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (529, 'sn12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (530, 'sn12', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (531, 'st09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (532, 'sn13', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (533, 'sn06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (534, 'sn06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (535, 'ns02', 'mt03', 130);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (536, 'ns02', 'sy31', 150);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (537, 'ns02', 're14', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (538, 'ns02', 'sy15', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (539, 'ns02', 'sy16', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (540, 'ns02', 'sy03', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (541, 'ns02', 'sy32', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (542, 'ns02', 'sy19', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (543, 'ns04', 'mt03', 130);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (544, 'ns04', 'sy31', 150);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (545, 'ns04', 're14', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (546, 'ns04', 'sy15', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (547, 'ns04', 'sy16', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (548, 'ns04', 'sy03', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (549, 'ns04', 'sy32', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (550, 'ns04', 'sy19', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (551, 'ns03', 'mt03', 130);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (552, 'ns03', 'sy31', 150);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (553, 'ns03', 're14', 2);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (554, 'ns03', 'sy15', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (555, 'ns03', 'sy16', 5);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (556, 'ns03', 'sy03', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (557, 'ns03', 'sy32', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (558, 'ns03', 'sy19', 10);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (559, 'pz02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (560, 'pz01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (561, 'pz03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (562, 'pz03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (563, 'pz05', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (564, 'sn07', 'sy33', 160);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (565, 'sn07', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (566, 'sn09', 'sy32', 150);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (567, 'sn09', 'bt30', 30);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (568, 'sn09', 'bt22', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (569, 'sn09', 're08', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (570, 'sn09', 're07', 1);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (571, 'sl', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (572, 'sl', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (573, 'es03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (574, 'es03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (575, 'es03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (576, 'es02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (577, 'es02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (578, 'es01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (579, 'jc01', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (580, 'jc15', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (581, 'jc06', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (582, 'jc07', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (583, 'jc19', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (584, 'jc22', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (585, 'jc09', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (586, 'jc25', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (587, 'jc10', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (588, 'jc27', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (589, 'jc11', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (590, 'jc28', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (591, 'jc08', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (592, 'jc29', '', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (593, 'ac02', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (594, 'ac04', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (595, 'ac03', 'mt02', 0);
INSERT INTO bom (`id`, `idProduk`, `idBahanBaku`, `qty`) VALUES (596, 'ac14', 'ac14', 1);


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (2, 'bb02', 'botol dan kaleng');
INSERT INTO categories (`id`, `code`, `name`) VALUES (3, 'bb01', 'daging');
INSERT INTO categories (`id`, `code`, `name`) VALUES (4, 'bb03', 'tepung dan lain-lain');
INSERT INTO categories (`id`, `code`, `name`) VALUES (5, 'bb04', 'rempah-rempah');
INSERT INTO categories (`id`, `code`, `name`) VALUES (6, 'bb05', 'sayuran dan buah');
INSERT INTO categories (`id`, `code`, `name`) VALUES (7, 'fd', 'makanan');
INSERT INTO categories (`id`, `code`, `name`) VALUES (8, 'mm02', 'minuman');
INSERT INTO categories (`id`, `code`, `name`) VALUES (9, 'ic01', 'ice cream');
INSERT INTO categories (`id`, `code`, `name`) VALUES (10, 'sa01', 'bahan saos');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');
INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Gamantha Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\n&lt;p&gt;\n                This is latest the latest release of Stock Manager Advance.\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'GENERAL CUSTOMER', 'seventhsin', 'YOS SUDARSO 8-9', 'PALU', 'SULTENG', '-', 'INDONESIA', '0123456789', 'general@seventhsin.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yyyy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yyyy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS log;

CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduk` varchar(25) NOT NULL,
  `qty` int(11) NOT NULL,
  `namaTransaksi` varchar(100) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1495 DEFAULT CHARSET=latin1;

INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1, 'mt01', 0, 'Tambah Data Produk', '2017-10-12 10:36:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (2, 'mt02', 0, 'Tambah Data Produk', '2017-10-12 10:41:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (3, 'mt03', 0, 'Tambah Data Produk', '2017-10-12 10:48:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (4, 'mt04', 0, 'Tambah Data Produk', '2017-10-12 10:56:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (5, 'mt05', 0, 'Tambah Data Produk', '2017-10-12 10:58:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (6, 'mt06', 0, 'Tambah Data Produk', '2017-10-12 10:59:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (7, 'mt07', 0, 'Tambah Data Produk', '2017-10-12 11:00:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (8, 'mt08', 0, 'Tambah Data Produk', '2017-10-12 11:02:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (9, 'mt09', 0, 'Tambah Data Produk', '2017-10-12 11:05:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (10, 'mt10', 0, 'Tambah Data Produk', '2017-10-12 11:06:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (11, 'mt11', 0, 'Tambah Data Produk', '2017-10-12 11:09:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (12, 'mt12', 0, 'Tambah Data Produk', '2017-10-12 11:12:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (13, 'mt13', 0, 'Tambah Data Produk', '2017-10-12 11:16:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (14, 'bt01', 0, 'Tambah Data Produk', '2017-10-12 11:18:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (15, 'bt02', 0, 'Tambah Data Produk', '2017-10-12 11:19:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (16, 'bt03', 0, 'Tambah Data Produk', '2017-10-12 11:20:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (17, 'bt04', 0, 'Tambah Data Produk', '2017-10-12 11:21:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (18, 'bt05', 0, 'Tambah Data Produk', '2017-10-12 11:21:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (19, 'bt06', 0, 'Tambah Data Produk', '2017-10-12 11:22:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (20, 'bt07', 0, 'Tambah Data Produk', '2017-10-12 11:23:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (21, 'bt08', 0, 'Tambah Data Produk', '2017-10-12 11:23:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (22, 'bt09', 0, 'Tambah Data Produk', '2017-10-12 11:25:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (23, 'bt10', 0, 'Tambah Data Produk', '2017-10-12 11:25:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (24, 'bt11', 0, 'Tambah Data Produk', '2017-10-12 11:26:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (25, 'bt12', 0, 'Tambah Data Produk', '2017-10-12 11:26:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (26, 'bt13', 0, 'Tambah Data Produk', '2017-10-12 11:27:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (27, 'bt14', 0, 'Tambah Data Produk', '2017-10-12 11:37:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (28, 'bt15', 0, 'Tambah Data Produk', '2017-10-12 11:37:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (29, 'bt16', 0, 'Tambah Data Produk', '2017-10-12 11:38:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (30, 'bt17', 0, 'Tambah Data Produk', '2017-10-12 11:39:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (31, 'bt18', 0, 'Tambah Data Produk', '2017-10-12 11:39:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (32, 'bt19', 0, 'Tambah Data Produk', '2017-10-12 11:40:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (33, 'bt20', 0, 'Tambah Data Produk', '2017-10-12 11:40:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (34, 'bt21', 0, 'Tambah Data Produk', '2017-10-12 11:41:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (35, 'bt22', 0, 'Tambah Data Produk', '2017-10-12 11:41:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (36, 'bt23', 0, 'Tambah Data Produk', '2017-10-12 11:42:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (37, 'bt24', 0, 'Tambah Data Produk', '2017-10-12 11:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (38, 'ot01', 0, 'Tambah Data Produk', '2017-10-12 11:44:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (39, 'ot02', 0, 'Tambah Data Produk', '2017-10-12 11:44:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (40, 'ot03', 0, 'Tambah Data Produk', '2017-10-12 11:45:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (41, 'ot04', 0, 'Tambah Data Produk', '2017-10-12 11:45:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (42, 'ot05', 0, 'Tambah Data Produk', '2017-10-12 11:45:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (43, 'ot06', 0, 'Tambah Data Produk', '2017-10-12 11:46:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (44, 'ot07', 0, 'Tambah Data Produk', '2017-10-12 11:47:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (45, 'ot08', 0, 'Tambah Data Produk', '2017-10-12 11:48:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (46, 'ot09', 0, 'Tambah Data Produk', '2017-10-12 11:48:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (47, 'ot10', 0, 'Tambah Data Produk', '2017-10-12 11:49:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (48, 're01', 0, 'Tambah Data Produk', '2017-10-12 11:50:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (49, 're02', 0, 'Tambah Data Produk', '2017-10-12 11:51:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (50, 're03', 0, 'Tambah Data Produk', '2017-10-12 11:52:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (51, 're04', 0, 'Tambah Data Produk', '2017-10-12 11:52:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (52, 're05', 0, 'Tambah Data Produk', '2017-10-12 11:53:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (53, 're06', 0, 'Tambah Data Produk', '2017-10-12 11:53:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (54, 're07', 0, 'Tambah Data Produk', '2017-10-12 11:54:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (55, 're08', 0, 'Tambah Data Produk', '2017-10-12 11:54:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (56, 're09', 0, 'Tambah Data Produk', '2017-10-12 12:27:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (57, 're10', 0, 'Tambah Data Produk', '2017-10-12 12:27:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (58, 're11', 0, 'Tambah Data Produk', '2017-10-12 12:28:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (59, 're12', 0, 'Tambah Data Produk', '2017-10-12 12:28:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (60, 're13', 0, 'Tambah Data Produk', '2017-10-12 12:29:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (61, 're14', 0, 'Tambah Data Produk', '2017-10-12 12:29:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (62, 're15', 0, 'Tambah Data Produk', '2017-10-12 12:29:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (63, 're16', 0, 'Tambah Data Produk', '2017-10-12 12:30:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (64, 're17', 0, 'Tambah Data Produk', '2017-10-12 12:30:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (65, 're18', 0, 'Tambah Data Produk', '2017-10-12 12:31:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (66, 're19', 0, 'Tambah Data Produk', '2017-10-12 12:31:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (67, 're20', 0, 'Tambah Data Produk', '2017-10-12 12:47:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (68, 're21', 0, 'Tambah Data Produk', '2017-10-12 12:48:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (69, 'sy01', 0, 'Tambah Data Produk', '2017-10-12 12:50:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (70, 'sy02', 0, 'Tambah Data Produk', '2017-10-12 12:51:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (71, 'sy03', 0, 'Tambah Data Produk', '2017-10-12 12:51:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (72, 'sy04', 0, 'Tambah Data Produk', '2017-10-12 12:52:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (73, 'sy05', 0, 'Tambah Data Produk', '2017-10-12 12:52:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (74, 'sy06', 0, 'Tambah Data Produk', '2017-10-12 12:53:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (75, 'sy07', 0, 'Tambah Data Produk', '2017-10-12 12:54:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (76, 'sy08', 0, 'Tambah Data Produk', '2017-10-12 13:05:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (77, 'sy08', 0, 'Tambah Data Produk', '2017-10-12 13:06:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (78, 'sy09', 0, 'Tambah Data Produk', '2017-10-12 13:07:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (79, 'sy10', 0, 'Tambah Data Produk', '2017-10-12 13:08:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (80, 'sy11', 0, 'Tambah Data Produk', '2017-10-12 13:08:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (81, 'sy12', 0, 'Tambah Data Produk', '2017-10-12 13:09:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (82, 'sy13', 0, 'Tambah Data Produk', '2017-10-12 13:09:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (83, 'sy14', 0, 'Tambah Data Produk', '2017-10-12 13:10:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (84, 'sy15', 0, 'Tambah Data Produk', '2017-10-12 13:10:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (85, 'sy16', 0, 'Tambah Data Produk', '2017-10-12 13:11:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (86, 'sy17', 0, 'Tambah Data Produk', '2017-10-12 13:11:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (87, 'sy18', 0, 'Tambah Data Produk', '2017-10-12 13:12:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (88, 'sy19', 0, 'Tambah Data Produk', '2017-10-12 13:12:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (89, 'sy20', 0, 'Tambah Data Produk', '2017-10-12 13:13:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (90, 'sy21', 0, 'Tambah Data Produk', '2017-10-12 13:13:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (91, 'sy22', 0, 'Tambah Data Produk', '2017-10-12 13:14:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (92, 'sy23', 0, 'Tambah Data Produk', '2017-10-12 13:14:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (93, 'sy24', 0, 'Tambah Data Produk', '2017-10-12 13:15:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (94, 'sy25', 0, 'Tambah Data Produk', '2017-10-12 13:15:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (95, 'sy26', 0, 'Tambah Data Produk', '2017-10-12 13:16:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (96, 'sy27', 0, 'Tambah Data Produk', '2017-10-12 13:16:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (97, 'sy28', 0, 'Tambah Data Produk', '2017-10-12 13:17:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (98, 'sy29', 0, 'Tambah Data Produk', '2017-10-12 13:18:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (99, 'sy30', 0, 'Tambah Data Produk', '2017-10-12 13:18:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (100, 'sy31', 0, 'Tambah Data Produk', '2017-10-12 13:19:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (101, 'st01', 0, 'Tambah Data Produk', '2017-10-12 13:24:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (102, 'sy32', 0, 'Tambah Data Produk', '2017-10-12 13:26:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (103, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (104, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (105, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (106, 'st01', 1, 'Penjualan Produk', '2017-10-12 13:47:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (107, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (108, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (109, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 13:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (110, 'st01', 1, 'Penjualan Produk', '2017-10-12 13:51:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (111, 'mt01', 0, 'Tambah Data Produk', '2017-10-12 14:28:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (112, 'st01', 0, 'Tambah Data Produk', '2017-10-12 14:32:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (113, 'st02', 0, 'Tambah Data Produk', '2017-10-12 14:35:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (114, 'st03', 0, 'Tambah Data Produk', '2017-10-12 14:48:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (115, 'st04', 0, 'Tambah Data Produk', '2017-10-12 14:51:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (116, 'st05', 0, 'Tambah Data Produk', '2017-10-12 14:53:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (117, 'st06', 0, 'Tambah Data Produk', '2017-10-12 14:55:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (118, 'st07', 0, 'Tambah Data Produk', '2017-10-12 14:59:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (119, 'st08', 0, 'Tambah Data Produk', '2017-10-12 15:00:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (120, 'st09', 0, 'Tambah Data Produk', '2017-10-12 15:01:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (121, 'st10', 0, 'Tambah Data Produk', '2017-10-12 15:02:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (122, 'st11', 0, 'Tambah Data Produk', '2017-10-12 15:03:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (123, 'st12', 0, 'Tambah Data Produk', '2017-10-12 15:03:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (124, 'st13', 0, 'Tambah Data Produk', '2017-10-12 15:04:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (125, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (126, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (127, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (128, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (129, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (130, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (131, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (132, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (133, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (134, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (135, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (136, 'st01', 1, 'Penjualan Produk', '2017-10-12 15:20:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (137, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (138, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (139, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (140, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (141, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (142, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (143, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (144, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (145, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (146, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (147, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (148, 'st01', 1, 'Penjualan Produk', '2017-10-12 15:25:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (149, 'sy33', 0, 'Tambah Data Produk', '2017-10-12 16:08:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (150, 'sy34', 0, 'Tambah Data Produk', '2017-10-12 16:09:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (151, 'sn01', 0, 'Tambah Data Produk', '2017-10-12 16:17:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (152, 'ot11', 0, 'Tambah Data Produk', '2017-10-12 16:18:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (153, 'sn02', 0, 'Tambah Data Produk', '2017-10-12 16:21:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (154, 'sn03', 0, 'Tambah Data Produk', '2017-10-12 16:26:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (155, 'sn04', 0, 'Tambah Data Produk', '2017-10-12 16:29:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (156, 'sn05', 0, 'Tambah Data Produk', '2017-10-12 16:32:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (157, 'sp01', 0, 'Tambah Data Produk', '2017-10-12 16:35:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (158, 'sp02', 0, 'Tambah Data Produk', '2017-10-12 16:37:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (159, 'sn06', 0, 'Tambah Data Produk', '2017-10-12 16:39:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (160, 'ns01', 0, 'Tambah Data Produk', '2017-10-12 16:41:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (161, 'ns02', 0, 'Tambah Data Produk', '2017-10-12 16:44:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (162, 'ns03', 0, 'Tambah Data Produk', '2017-10-12 16:46:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (163, 'ns04', 0, 'Tambah Data Produk', '2017-10-12 16:47:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (164, 'ns05', 0, 'Tambah Data Produk', '2017-10-12 16:55:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (165, 'sy35', 0, 'Tambah Data Produk', '2017-10-12 16:58:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (166, 'ot12', 0, 'Tambah Data Produk', '2017-10-12 16:59:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (167, 'pz01', 0, 'Tambah Data Produk', '2017-10-12 17:01:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (168, 'pz02', 0, 'Tambah Data Produk', '2017-10-12 17:04:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (169, 'sy36', 0, 'Tambah Data Produk', '2017-10-12 17:06:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (170, 'pz03', 0, 'Tambah Data Produk', '2017-10-12 17:07:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (171, 'sy37', 0, 'Tambah Data Produk', '2017-10-12 17:08:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (172, 'pz04', 0, 'Tambah Data Produk', '2017-10-12 17:10:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (173, 'bt25', 0, 'Tambah Data Produk', '2017-10-12 17:11:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (174, 'sl', 0, 'Tambah Data Produk', '2017-10-12 17:13:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (175, 'sn07', 0, 'Tambah Data Produk', '2017-10-12 17:17:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (176, 'sn08', 0, 'Tambah Data Produk', '2017-10-12 17:19:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (177, 'sn09', 0, 'Tambah Data Produk', '2017-10-12 17:21:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (178, 'sn10', 0, 'Tambah Data Produk', '2017-10-12 17:22:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (179, 'sn11', 0, 'Tambah Data Produk', '2017-10-12 17:22:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (180, 'sn12', 0, 'Tambah Data Produk', '2017-10-12 17:23:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (181, 'sn13', 0, 'Tambah Data Produk', '2017-10-12 17:23:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (182, 'pz05', 0, 'Tambah Data Produk', '2017-10-12 17:24:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (183, 'pz06', 0, 'Tambah Data Produk', '2017-10-12 17:25:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (184, 'ns06', 0, 'Tambah Data Produk', '2017-10-12 17:25:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (185, 'es01', 0, 'Tambah Data Produk', '2017-10-12 17:26:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (186, 'es02', 0, 'Tambah Data Produk', '2017-10-12 17:27:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (187, 'es03', 0, 'Tambah Data Produk', '2017-10-12 17:27:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (188, 'jc01', 0, 'Tambah Data Produk', '2017-10-12 17:57:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (189, 'jc02', 0, 'Tambah Data Produk', '2017-10-12 17:58:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (190, 'jc03', 0, 'Tambah Data Produk', '2017-10-12 17:59:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (191, 'jc04', 0, 'Tambah Data Produk', '2017-10-12 18:00:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (192, 'jc05', 0, 'Tambah Data Produk', '2017-10-12 18:01:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (193, 'jc06', 0, 'Tambah Data Produk', '2017-10-12 18:03:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (194, 'jc07', 0, 'Tambah Data Produk', '2017-10-12 18:04:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (195, 'jc08', 0, 'Tambah Data Produk', '2017-10-12 18:05:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (196, 'bt26', 0, 'Tambah Data Produk', '2017-10-12 18:09:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (197, 'jc09', 0, 'Tambah Data Produk', '2017-10-12 18:10:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (198, 'bt27', 0, 'Tambah Data Produk', '2017-10-12 18:11:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (199, 'jc10', 0, 'Tambah Data Produk', '2017-10-12 18:13:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (200, 'bt28', 0, 'Tambah Data Produk', '2017-10-12 18:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (201, 'jc11', 0, 'Tambah Data Produk', '2017-10-12 18:14:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (202, 'bt29', 0, 'Tambah Data Produk', '2017-10-12 18:16:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (203, 'jc12', 0, 'Tambah Data Produk', '2017-10-12 18:17:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (204, 'jc13', 0, 'Tambah Data Produk', '2017-10-12 18:19:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (205, 'jc14', 0, 'Tambah Data Produk', '2017-10-12 18:19:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (206, 'jc15', 0, 'Tambah Data Produk', '2017-10-12 18:20:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (207, 'jc16', 0, 'Tambah Data Produk', '2017-10-12 19:12:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (208, 'jc17', 0, 'Tambah Data Produk', '2017-10-12 19:12:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (209, 'jc18', 0, 'Tambah Data Produk', '2017-10-12 19:13:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (210, 'jc19', 0, 'Tambah Data Produk', '2017-10-12 19:14:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (211, 'jc20', 0, 'Tambah Data Produk', '2017-10-12 19:15:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (212, 'jc21', 0, 'Tambah Data Produk', '2017-10-12 19:17:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (213, 'jc23', 0, 'Tambah Data Produk', '2017-10-12 19:20:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (214, 'jc24', 0, 'Tambah Data Produk', '2017-10-12 19:20:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (215, 'jc26', 0, 'Tambah Data Produk', '2017-10-12 19:21:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (216, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 19:37:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (217, 'sn11', 1, 'Penjualan Produk', '2017-10-12 19:37:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (218, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 19:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (219, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 19:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (220, 'sn10', 1, 'Penjualan Produk', '2017-10-12 19:50:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (221, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 19:52:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (222, 'sn11', 1, 'Penjualan Produk', '2017-10-12 19:52:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (223, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-12 19:54:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (224, 'sn11', 1, 'Penjualan Produk', '2017-10-12 19:54:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (225, 'ac01', 0, 'Tambah Data Produk', '2017-10-13 14:20:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (226, 'ac02', 0, 'Tambah Data Produk', '2017-10-13 14:21:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (227, 'ac03', 0, 'Tambah Data Produk', '2017-10-13 14:22:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (228, 'ac04', 0, 'Tambah Data Produk', '2017-10-13 14:24:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (229, 'ac05', 0, 'Tambah Data Produk', '2017-10-13 14:24:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (230, 'ac06', 0, 'Tambah Data Produk', '2017-10-13 14:25:34');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (231, 'ac07', 0, 'Tambah Data Produk', '2017-10-13 14:26:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (232, 'ac08', 0, 'Tambah Data Produk', '2017-10-13 14:28:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (233, 'ac09', 0, 'Tambah Data Produk', '2017-10-13 14:29:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (234, 'ac10', 0, 'Tambah Data Produk', '2017-10-13 14:32:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (235, 'ac11', 0, 'Tambah Data Produk', '2017-10-13 14:33:58');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (236, 'ac12', 0, 'Tambah Data Produk', '2017-10-13 14:34:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (237, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 06:00:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (238, 'jc26', 1, 'Penjualan Produk', '2017-10-14 06:00:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (239, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 06:06:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (240, 'jc26', 1, 'Penjualan Produk', '2017-10-14 06:06:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (241, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 06:17:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (242, 'jc26', 1, 'Penjualan Produk', '2017-10-14 06:17:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (243, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 06:28:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (244, 'ns05', 1, 'Penjualan Produk', '2017-10-14 06:28:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (245, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 15:35:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (246, 'ns05', 1, 'Penjualan Produk', '2017-10-13 15:35:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (247, 'pz04', 0, 'Edit Data Produk', '2017-10-13 16:03:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (248, 'pz04', 0, 'Edit Data Produk', '2017-10-13 16:03:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (249, 'pz03', 0, 'Edit Data Produk', '2017-10-13 16:03:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (250, 'sl', 0, 'Edit Data Produk', '2017-10-13 18:38:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (251, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (252, 'ns01', 1, 'Penjualan Produk', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (253, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (254, 'ns01', 1, 'Penjualan Produk', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (255, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (256, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (257, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (258, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (259, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (260, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:35:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (261, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:37:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (262, 'ns01', 1, 'Penjualan Produk', '2017-10-13 19:37:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (263, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:37:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (264, 'ns01', 1, 'Penjualan Produk', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (265, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (266, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (267, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (268, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (269, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (270, 'jc26', 1, 'Penjualan Produk', '2017-10-13 19:37:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (271, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:01:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (272, 'jc26', 1, 'Penjualan Produk', '2017-10-13 20:01:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (273, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:13:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (274, 'ns01', 1, 'Penjualan Produk', '2017-10-13 20:13:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (275, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:13:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (276, 'pz02', 1, 'Penjualan Produk', '2017-10-13 20:13:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (277, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:13:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (278, 'jc19', 1, 'Penjualan Produk', '2017-10-13 20:13:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (279, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:43:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (280, 'jc26', 1, 'Penjualan Produk', '2017-10-13 20:43:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (281, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:43:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (282, 'jc26', 1, 'Penjualan Produk', '2017-10-13 20:43:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (283, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 20:50:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (284, 'jc11', 1, 'Penjualan Produk', '2017-10-13 20:50:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (285, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:12:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (286, 'sp02', 1, 'Penjualan Produk', '2017-10-13 22:12:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (287, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:12:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (288, 'jc19', 1, 'Penjualan Produk', '2017-10-13 22:12:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (289, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:12:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (290, 'pz01', 1, 'Penjualan Produk', '2017-10-13 22:12:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (291, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:12:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (292, 'pz05', 1, 'Penjualan Produk', '2017-10-13 22:12:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (293, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (294, 'ns05', 1, 'Penjualan Produk', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (295, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (296, 'jc03', 1, 'Penjualan Produk', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (297, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (298, 'jc26', 1, 'Penjualan Produk', '2017-10-13 22:38:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (299, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (300, 'sp02', 1, 'Penjualan Produk', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (301, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (302, 'ac03', 1, 'Penjualan Produk', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (303, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (304, 'ac07', 1, 'Penjualan Produk', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (305, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (306, 'sn02', 1, 'Penjualan Produk', '2017-10-13 22:43:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (307, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (308, 'sn03', 1, 'Penjualan Produk', '2017-10-13 23:27:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (309, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (310, 'ac09', 1, 'Penjualan Produk', '2017-10-13 23:27:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (311, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (312, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (313, 'pz03', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (314, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (315, 'jc03', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (316, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (317, 'jc03', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (318, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (319, 'jc20', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (320, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (321, 'ac09', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (322, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (323, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (324, 'sn04', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (325, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (326, 'ac09', 1, 'Penjualan Produk', '2017-10-13 23:27:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (327, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:21:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (328, 'pz01', 1, 'Penjualan Produk', '2017-10-14 00:21:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (329, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:21:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (330, 'ac03', 1, 'Penjualan Produk', '2017-10-14 00:21:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (331, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (332, 'ns01', 1, 'Penjualan Produk', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (333, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (334, 'ns05', 1, 'Penjualan Produk', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (335, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (336, 'jc26', 1, 'Penjualan Produk', '2017-10-14 00:23:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (337, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (338, 'jc26', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (339, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (340, 'sp02', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (341, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (342, 'ac02', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (343, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (344, 'ac02', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (345, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (346, 'ac02', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (347, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (348, 'ac02', 1, 'Penjualan Produk', '2017-10-14 00:23:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (349, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (350, 'ns05', 1, 'Penjualan Produk', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (351, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (352, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (353, 'pz03', 1, 'Penjualan Produk', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (354, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (355, 'ac07', 1, 'Penjualan Produk', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (356, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (357, 'jc20', 1, 'Penjualan Produk', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (358, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (359, 'ac07', 1, 'Penjualan Produk', '2017-10-14 00:26:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (360, 'jc26', 0, 'Edit Data Produk', '2017-10-14 17:03:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (361, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (362, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (363, 'pz03', 1, 'Penjualan Produk', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (364, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (365, 'jc08', 1, 'Penjualan Produk', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (366, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (367, 'jc13', 1, 'Penjualan Produk', '2017-10-14 20:19:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (368, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (369, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (370, 'jc26', 1, 'Penjualan Produk', '2017-10-14 20:19:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (371, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:19:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (372, 'ns04', 1, 'Penjualan Produk', '2017-10-14 20:19:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (373, 'st06', 0, 'Edit Data Produk', '2017-10-14 20:20:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (374, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (375, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (376, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (377, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (378, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (379, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (380, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (381, 'st02', 1, 'Penjualan Produk', '2017-10-14 20:33:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (382, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (383, 'st09', 1, 'Penjualan Produk', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (384, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (385, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (386, 'st05', 1, 'Penjualan Produk', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (387, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (388, 'st10', 1, 'Penjualan Produk', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (389, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (390, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (391, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (392, 'st03', 1, 'Penjualan Produk', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (393, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (394, 'st09', 1, 'Penjualan Produk', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (395, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (396, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (397, 'st04', 1, 'Penjualan Produk', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (398, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (399, 'jc19', 1, 'Penjualan Produk', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (400, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (401, 'jc19', 1, 'Penjualan Produk', '2017-10-14 20:33:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (402, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (403, 'jc20', 1, 'Penjualan Produk', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (404, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (405, 'jc08', 1, 'Penjualan Produk', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (406, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (407, 'jc08', 1, 'Penjualan Produk', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (408, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (409, 'jc10', 1, 'Penjualan Produk', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (410, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (411, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (412, 'st06', 1, 'Penjualan Produk', '2017-10-14 21:08:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (413, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:08:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (414, 'st07', 1, 'Penjualan Produk', '2017-10-14 21:08:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (415, 'sn05', 0, 'Edit Data Produk', '2017-10-14 21:18:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (416, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (417, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (418, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (419, 'st03', 1, 'Penjualan Produk', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (420, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (421, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (422, 'st06', 1, 'Penjualan Produk', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (423, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (424, 'st09', 1, 'Penjualan Produk', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (425, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (426, 'sp01', 1, 'Penjualan Produk', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (427, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (428, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (429, 'pz03', 1, 'Penjualan Produk', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (430, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (431, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (432, 'jc26', 1, 'Penjualan Produk', '2017-10-14 21:47:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (433, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:47:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (434, 'jc07', 1, 'Penjualan Produk', '2017-10-14 21:47:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (435, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (436, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (437, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (438, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (439, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (440, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (441, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (442, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (443, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (444, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (445, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (446, 'st01', 1, 'Penjualan Produk', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (447, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (448, 'st08', 1, 'Penjualan Produk', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (449, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (450, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (451, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (452, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (453, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (454, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (455, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (456, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (457, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (458, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (459, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (460, 'st01', 1, 'Penjualan Produk', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (461, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (462, 'st09', 1, 'Penjualan Produk', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (463, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (464, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (465, 'sn05', 1, 'Penjualan Produk', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (466, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (467, 'ns01', 1, 'Penjualan Produk', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (468, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (469, 'jc03', 1, 'Penjualan Produk', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (470, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (471, 'jc03', 1, 'Penjualan Produk', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (472, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (473, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (474, 'jc26', 1, 'Penjualan Produk', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (475, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (476, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (477, 'jc26', 1, 'Penjualan Produk', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (478, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (479, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (480, 'jc26', 1, 'Penjualan Produk', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (481, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (482, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (483, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (484, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (485, 'pz04', 1, 'Penjualan Produk', '2017-10-14 21:50:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (486, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 21:50:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (487, 'sn03', 1, 'Penjualan Produk', '2017-10-14 21:50:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (488, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (489, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (490, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (491, 'st03', 1, 'Penjualan Produk', '2017-10-14 22:10:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (492, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (493, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (494, 'sn12', 1, 'Penjualan Produk', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (495, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (496, 'st10', 1, 'Penjualan Produk', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (497, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (498, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (499, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (500, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (501, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (502, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (503, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (504, 'st02', 1, 'Penjualan Produk', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (505, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (506, 'st08', 1, 'Penjualan Produk', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (507, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (508, 'st10', 1, 'Penjualan Produk', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (509, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (510, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (511, 'st04', 1, 'Penjualan Produk', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (512, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (513, 'jc15', 1, 'Penjualan Produk', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (514, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (515, 'ac10', 1, 'Penjualan Produk', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (516, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (517, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (518, 'st06', 1, 'Penjualan Produk', '2017-10-14 22:10:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (519, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (520, 'jc11', 1, 'Penjualan Produk', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (521, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (522, 'jc11', 1, 'Penjualan Produk', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (523, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (524, 'jc08', 1, 'Penjualan Produk', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (525, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (526, 'jc14', 1, 'Penjualan Produk', '2017-10-14 22:40:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (527, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (528, 'pz01', 1, 'Penjualan Produk', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (529, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (530, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (531, 'sn04', 1, 'Penjualan Produk', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (532, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (533, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (534, 'jc26', 1, 'Penjualan Produk', '2017-10-14 22:40:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (535, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:58:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (536, 'ac02', 1, 'Penjualan Produk', '2017-10-14 22:58:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (537, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (538, 'ac02', 1, 'Penjualan Produk', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (539, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (540, 'ac03', 1, 'Penjualan Produk', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (541, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (542, 'ac03', 1, 'Penjualan Produk', '2017-10-14 22:58:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (543, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (544, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (545, 'pz03', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (546, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (547, 'jc03', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (548, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (549, 'jc09', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (550, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (551, 'jc09', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (552, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (553, 'jc12', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (554, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (555, 'ac04', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (556, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (557, 'sn03', 1, 'Penjualan Produk', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (558, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (559, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (560, 'st04', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (561, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (562, 'pz02', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (563, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (564, 'ns03', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (565, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (566, 'sp01', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (567, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (568, 'ns01', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (569, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (570, 'jc11', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (571, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (572, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (573, 'jc26', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (574, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (575, 'pz01', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (576, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (577, 'jc03', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (578, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (579, 'jc15', 1, 'Penjualan Produk', '2017-10-14 23:29:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (580, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (581, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (582, 'sn04', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (583, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (584, 'ac04', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (585, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (586, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (587, 'pz03', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (588, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (589, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (590, 'jc26', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (591, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (592, 'ac10', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (593, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (594, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (595, 'jc26', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (596, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (597, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (598, 'jc26', 1, 'Penjualan Produk', '2017-10-14 23:29:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (599, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (600, 'pz01', 1, 'Penjualan Produk', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (601, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (602, 'jc06', 1, 'Penjualan Produk', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (603, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (604, 'jc08', 1, 'Penjualan Produk', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (605, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (606, 'ac02', 1, 'Penjualan Produk', '2017-10-15 00:00:46');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (607, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (608, 'ac02', 1, 'Penjualan Produk', '2017-10-15 00:12:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (609, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (610, 'ns04', 1, 'Penjualan Produk', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (611, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (612, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (613, 'jc26', 1, 'Penjualan Produk', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (614, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (615, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (616, 'jc26', 1, 'Penjualan Produk', '2017-10-15 00:12:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (617, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:15:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (618, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 00:15:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (619, 'jc26', 1, 'Penjualan Produk', '2017-10-15 00:15:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (620, 'jc16', 0, 'Edit Data Produk', '2017-10-15 13:28:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (621, 'jc17', 0, 'Edit Data Produk', '2017-10-15 13:28:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (622, 'jc18', 0, 'Edit Data Produk', '2017-10-15 13:29:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (623, 'jc16', 0, 'Edit Data Produk', '2017-10-15 13:30:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (624, 'jc16', 0, 'Edit Data Produk', '2017-10-15 13:31:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (625, 'jc17', 0, 'Edit Data Produk', '2017-10-15 13:31:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (626, 'jc18', 0, 'Edit Data Produk', '2017-10-15 13:31:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (627, 'ac13', 0, 'Tambah Data Produk', '2017-10-15 13:33:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (628, 'ac14', 0, 'Tambah Data Produk', '2017-10-15 13:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (629, 'ac15', 0, 'Tambah Data Produk', '2017-10-15 13:35:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (630, 'ac16', 0, 'Tambah Data Produk', '2017-10-15 13:36:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (631, 'ac17', 0, 'Tambah Data Produk', '2017-10-15 13:37:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (632, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (633, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (634, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (635, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (636, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (637, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (638, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (639, 'st02', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (640, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (641, 'st07', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (642, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (643, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (644, 'st04', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (645, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (646, 'sn08', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (647, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (648, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (649, 'sn04', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (650, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (651, 'sp02', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (652, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (653, 'jc04', 1, 'Penjualan Produk', '2017-10-15 19:49:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (654, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (655, 'jc15', 1, 'Penjualan Produk', '2017-10-15 19:49:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (656, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:49:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (657, 'jc23', 1, 'Penjualan Produk', '2017-10-15 19:49:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (658, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (659, 'ns01', 1, 'Penjualan Produk', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (660, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (661, 'ns01', 1, 'Penjualan Produk', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (662, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (663, 'ns01', 1, 'Penjualan Produk', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (664, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (665, 'sl', 1, 'Penjualan Produk', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (666, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (667, 'sp01', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (668, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (669, 'sp02', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (670, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (671, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (672, 'st04', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (673, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (674, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (675, 'jc26', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (676, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (677, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (678, 'jc26', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (679, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (680, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (681, 'jc26', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (682, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (683, 'jc07', 1, 'Penjualan Produk', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (684, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (685, 'sn07', 1, 'Penjualan Produk', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (686, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (687, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (688, 'jc26', 1, 'Penjualan Produk', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (689, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (690, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (691, 'jc26', 1, 'Penjualan Produk', '2017-10-15 19:51:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (692, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (693, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (694, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (695, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (696, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (697, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (698, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (699, 'st02', 1, 'Penjualan Produk', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (700, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (701, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (702, 'st05', 1, 'Penjualan Produk', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (703, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (704, 'st09', 1, 'Penjualan Produk', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (705, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (706, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (707, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (708, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (709, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (710, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (711, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (712, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (713, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (714, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (715, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (716, 'st01', 1, 'Penjualan Produk', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (717, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (718, 'st07', 1, 'Penjualan Produk', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (719, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (720, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (721, 'st04', 1, 'Penjualan Produk', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (722, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (723, 'sp01', 1, 'Penjualan Produk', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (724, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (725, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (726, 'sn05', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (727, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (728, 'jc23', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (729, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (730, 'jc11', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (731, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (732, 'jc11', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (733, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (734, 'jc13', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (735, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (736, 'ns02', 1, 'Penjualan Produk', '2017-10-15 20:22:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (737, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:39:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (738, 'sp02', 1, 'Penjualan Produk', '2017-10-15 20:39:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (739, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:39:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (740, 'jc06', 1, 'Penjualan Produk', '2017-10-15 20:39:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (741, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:39:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (742, 'jc11', 1, 'Penjualan Produk', '2017-10-15 20:39:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (743, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (744, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (745, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (746, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (747, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (748, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (749, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (750, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (751, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (752, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (753, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (754, 'st01', 1, 'Penjualan Produk', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (755, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (756, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (757, 'st04', 1, 'Penjualan Produk', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (758, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (759, 'st10', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (760, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (761, 'st07', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (762, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (763, 'jc11', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (764, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (765, 'ac04', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (766, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (767, 'st13', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (768, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (769, 'st12', 1, 'Penjualan Produk', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (770, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (771, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (772, 'st04', 1, 'Penjualan Produk', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (773, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (774, 'sn03', 1, 'Penjualan Produk', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (775, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (776, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (777, 'sn04', 1, 'Penjualan Produk', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (778, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (779, 'jc19', 1, 'Penjualan Produk', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (780, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (781, 'jc19', 1, 'Penjualan Produk', '2017-10-15 20:50:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (782, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (783, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (784, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (785, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (786, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (787, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (788, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (789, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (790, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (791, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (792, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (793, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (794, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (795, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (796, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (797, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:13:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (798, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (799, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (800, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (801, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (802, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (803, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (804, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (805, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (806, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (807, 'st13', 1, 'Penjualan Produk', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (808, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (809, 'ns02', 1, 'Penjualan Produk', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (810, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (811, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (812, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (813, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (814, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (815, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (816, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (817, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (818, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (819, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (820, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (821, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (822, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (823, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (824, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (825, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (826, 'jc11', 1, 'Penjualan Produk', '2017-10-15 21:13:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (827, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (828, 'jc23', 1, 'Penjualan Produk', '2017-10-15 21:13:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (829, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:13:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (830, 'jc19', 1, 'Penjualan Produk', '2017-10-15 21:13:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (831, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (832, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (833, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (834, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (835, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (836, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (837, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (838, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (839, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (840, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (841, 'st04', 1, 'Penjualan Produk', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (842, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (843, 'st08', 1, 'Penjualan Produk', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (844, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (845, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (846, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (847, 'st03', 1, 'Penjualan Produk', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (848, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (849, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (850, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (851, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (852, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (853, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (854, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (855, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (856, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (857, 'st08', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (858, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (859, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (860, 'st05', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (861, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (862, 'sp02', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (863, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (864, 'jc11', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (865, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (866, 'jc11', 1, 'Penjualan Produk', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (867, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (868, 'jc08', 1, 'Penjualan Produk', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (869, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (870, 'jc04', 1, 'Penjualan Produk', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (871, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (872, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (873, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (874, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (875, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (876, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (877, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (878, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (879, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (880, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (881, 'st05', 1, 'Penjualan Produk', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (882, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (883, 'st09', 1, 'Penjualan Produk', '2017-10-15 21:21:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (884, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (885, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (886, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (887, 'st03', 1, 'Penjualan Produk', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (888, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (889, 'jc19', 1, 'Penjualan Produk', '2017-10-15 21:21:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (890, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (891, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (892, 'sn04', 1, 'Penjualan Produk', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (893, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (894, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (895, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (896, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (897, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (898, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (899, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (900, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (901, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (902, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (903, 'st04', 1, 'Penjualan Produk', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (904, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (905, 'st13', 1, 'Penjualan Produk', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (906, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (907, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (908, 'st05', 1, 'Penjualan Produk', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (909, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (910, 'st09', 1, 'Penjualan Produk', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (911, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (912, 'ac03', 1, 'Penjualan Produk', '2017-10-15 21:23:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (913, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:29:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (914, 'jc11', 1, 'Penjualan Produk', '2017-10-15 21:29:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (915, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:29:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (916, 'jc13', 1, 'Penjualan Produk', '2017-10-15 21:29:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (917, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:29:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (918, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:29:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (919, 'pz03', 1, 'Penjualan Produk', '2017-10-15 21:29:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (920, 'sy32', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (921, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (922, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (923, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (924, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (925, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (926, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (927, 'st02', 1, 'Penjualan Produk', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (928, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (929, 'st07', 1, 'Penjualan Produk', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (930, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (931, 'st10', 1, 'Penjualan Produk', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (932, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (933, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (934, 'st04', 1, 'Penjualan Produk', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (935, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (936, 'ns03', 1, 'Penjualan Produk', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (937, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (938, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:34:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (939, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:34:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (940, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:36:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (941, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:36:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (942, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:36:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (943, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (944, 'sn03', 1, 'Penjualan Produk', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (945, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (946, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (947, 'sn04', 1, 'Penjualan Produk', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (948, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (949, 'sp02', 1, 'Penjualan Produk', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (950, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (951, 'jc15', 1, 'Penjualan Produk', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (952, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (953, 'jc06', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (954, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (955, 'jc03', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (956, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (957, 'ac04', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (958, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (959, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (960, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (961, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (962, 'pz04', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (963, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (964, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (965, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (966, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (967, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (968, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:58:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (969, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (970, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 21:58:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (971, 'jc26', 1, 'Penjualan Produk', '2017-10-15 21:58:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (972, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (973, 'sp02', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (974, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (975, 'sn03', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (976, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (977, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (978, 'sn04', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (979, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (980, 'jc15', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (981, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (982, 'jc03', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (983, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (984, 'jc06', 1, 'Penjualan Produk', '2017-10-15 22:01:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (985, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (986, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (987, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (988, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (989, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (990, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (991, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (992, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (993, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (994, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (995, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (996, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (997, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (998, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (999, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:01:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1000, 'pz04', 1, 'Penjualan Produk', '2017-10-15 22:01:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1001, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1002, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1003, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1004, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1005, 'jc10', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1006, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1007, 'jc10', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1008, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1009, 'jc23', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1010, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1011, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1012, 'pz03', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1013, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1014, 'pz01', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1015, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1016, 'ns01', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1017, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1018, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1019, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:04:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1020, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1021, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1022, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1023, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1024, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1025, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1026, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1027, 'sn07', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1028, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1029, 'jc21', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1030, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1031, 'jc08', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1032, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1033, 'jc08', 1, 'Penjualan Produk', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1034, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1035, 'jc08', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1036, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1037, 'jc08', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1038, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1039, 'pz02', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1040, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1041, 'pz01', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1042, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1043, 'pz01', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1044, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1045, 'ns01', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1046, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1047, 'ns01', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1048, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1049, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1050, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1051, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1052, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1053, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1054, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1055, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1056, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1057, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1058, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1059, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1060, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1061, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1062, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1063, 'ac04', 1, 'Penjualan Produk', '2017-10-15 22:04:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1064, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:51:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1065, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 22:51:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1066, 'jc26', 1, 'Penjualan Produk', '2017-10-15 22:51:14');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1067, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1068, 'st13', 1, 'Penjualan Produk', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1069, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1070, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1071, 'st06', 1, 'Penjualan Produk', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1072, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1073, 'st07', 1, 'Penjualan Produk', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1074, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1075, 'st10', 1, 'Penjualan Produk', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1076, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1077, 'st13', 1, 'Penjualan Produk', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1078, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1079, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1080, 'st04', 1, 'Penjualan Produk', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1081, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1082, 'st07', 1, 'Penjualan Produk', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1083, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1084, 'st10', 1, 'Penjualan Produk', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1085, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1086, 'bt21', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1087, 'mt01', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1088, 'mt01', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1089, 'sy32', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1090, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1091, 're18', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1092, 're08', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1093, 're02', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1094, 'bt05', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1095, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1096, 'st01', 1, 'Penjualan Produk', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1097, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1098, 'st08', 1, 'Penjualan Produk', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1099, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1100, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1101, 'st06', 1, 'Penjualan Produk', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1102, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1103, 'st11', 1, 'Penjualan Produk', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1104, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1105, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1106, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1107, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1108, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1109, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1110, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1111, 'ns06', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1112, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1113, 'st13', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1114, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1115, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1116, 'st04', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1117, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1118, 'ac10', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1119, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1120, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1121, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:00:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1122, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1123, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:00:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1124, 'pz03', 1, 'Penjualan Produk', '2017-10-15 23:00:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1125, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1126, 'ns01', 1, 'Penjualan Produk', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1127, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1128, 'sn03', 1, 'Penjualan Produk', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1129, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1130, 'jc09', 1, 'Penjualan Produk', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1131, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1132, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1133, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1134, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1135, 'pz04', 1, 'Penjualan Produk', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1136, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1137, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1138, 'st04', 1, 'Penjualan Produk', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1139, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1140, 'jc09', 1, 'Penjualan Produk', '2017-10-15 23:09:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1141, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1142, 'st13', 1, 'Penjualan Produk', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1143, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1144, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1145, 'st05', 1, 'Penjualan Produk', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1146, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1147, 'st07', 1, 'Penjualan Produk', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1148, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1149, 'jc14', 1, 'Penjualan Produk', '2017-10-15 23:22:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1150, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1151, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1152, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1153, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1154, 'ac07', 1, 'Penjualan Produk', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1155, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1156, 'ns03', 1, 'Penjualan Produk', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1157, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1158, 'ns03', 1, 'Penjualan Produk', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1159, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1160, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1161, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:22:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1162, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1163, 'sp02', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1164, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1165, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1166, 'st04', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1167, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1168, 'ns02', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1169, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1170, 'sn03', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1171, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1172, 'ac04', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1173, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1174, 'ac04', 1, 'Penjualan Produk', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1175, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1176, 'ac03', 1, 'Penjualan Produk', '2017-10-15 23:36:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1177, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:36:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1178, 'ac03', 1, 'Penjualan Produk', '2017-10-15 23:36:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1179, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:43:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1180, 'ac07', 1, 'Penjualan Produk', '2017-10-15 23:43:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1181, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1182, 'ns01', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1183, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1184, 'ns01', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1185, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1186, 'sp01', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1187, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1188, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1189, 'sn04', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1190, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1191, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1192, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1193, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1194, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1195, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:49:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1196, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1197, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1198, 'jc26', 1, 'Penjualan Produk', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1199, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1200, 'ac03', 1, 'Penjualan Produk', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1201, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1202, 'jc11', 1, 'Penjualan Produk', '2017-10-15 23:49:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1203, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1204, 'ns03', 1, 'Penjualan Produk', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1205, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1206, 'ns03', 1, 'Penjualan Produk', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1207, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1208, 'jc07', 1, 'Penjualan Produk', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1209, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1210, 'jc04', 1, 'Penjualan Produk', '2017-10-16 00:03:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1211, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1212, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1213, 'jc26', 1, 'Penjualan Produk', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1214, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1215, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1216, 'jc26', 1, 'Penjualan Produk', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1217, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1218, 'ac12', 1, 'Penjualan Produk', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1219, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1220, 'sn07', 1, 'Penjualan Produk', '2017-10-16 00:03:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1221, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:55:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1222, 'ac10', 1, 'Penjualan Produk', '2017-10-16 00:55:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1223, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:55:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1224, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 00:55:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1225, 'jc26', 1, 'Penjualan Produk', '2017-10-16 00:55:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1226, 'jc21', 0, 'Edit Data Produk', '2017-10-16 12:35:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1227, 'jc16', 0, 'Edit Data Produk', '2017-10-16 12:47:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1228, 'jc18', 0, 'Edit Data Produk', '2017-10-16 12:47:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1229, 'jc18', 0, 'Edit Data Produk', '2017-10-16 12:48:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1230, 'jc17', 0, 'Edit Data Produk', '2017-10-16 12:48:44');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1231, 'jc16', 0, 'Edit Data Produk', '2017-10-16 12:49:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1232, 'ac13', 0, 'Edit Data Produk', '2017-10-16 12:50:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1233, 'jc18', 0, 'Edit Data Produk', '2017-10-16 12:50:30');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1234, 'jc18', 0, 'Edit Data Produk', '2017-10-16 12:50:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1235, 'jc17', 0, 'Edit Data Produk', '2017-10-16 12:51:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1236, 'jc18', 0, 'Edit Data Produk', '2017-10-16 12:51:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1237, 'jc17', 0, 'Edit Data Produk', '2017-10-16 12:51:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1238, 'jc16', 0, 'Edit Data Produk', '2017-10-16 12:51:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1239, 'ac17', 0, 'Edit Data Produk', '2017-10-16 12:51:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1240, 'jc16', 0, 'Edit Data Produk', '2017-10-16 12:51:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1241, 'ac16', 0, 'Edit Data Produk', '2017-10-16 12:52:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1242, 'ac15', 0, 'Edit Data Produk', '2017-10-16 12:52:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1243, 'ac14', 0, 'Edit Data Produk', '2017-10-16 12:52:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1244, 'ac13', 0, 'Edit Data Produk', '2017-10-16 12:52:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1245, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:17:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1246, 'sy20', 0, 'Tambah Data Produk', '2017-10-16 14:18:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1247, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:20:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1248, 're18', 0, 'Tambah Data Produk', '2017-10-16 14:21:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1249, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:23:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1250, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:24:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1251, 're22', 0, 'Tambah Data Produk', '2017-10-16 14:25:02');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1252, 're22', 0, 'Edit Data Produk', '2017-10-16 14:25:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1253, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:25:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1254, 'st04', 0, 'Edit Data Produk', '2017-10-16 14:26:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1255, 'st05', 0, 'Edit Data Produk', '2017-10-16 14:27:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1256, 'st04', 0, 'Edit Data Produk', '2017-10-16 14:27:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1257, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:28:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1258, 'sy32', 0, 'Tambah Data Produk', '2017-10-16 14:28:33');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1259, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:28:53');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1260, 'st09', 0, 'Edit Data Produk', '2017-10-16 14:29:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1261, 'st02', 0, 'Edit Data Produk', '2017-10-16 14:31:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1262, 'st03', 0, 'Edit Data Produk', '2017-10-16 14:33:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1263, 'sn01', 0, 'Edit Data Produk', '2017-10-16 14:34:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1264, 'st13', 0, 'Edit Data Produk', '2017-10-16 14:35:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1265, 'mt04', 0, 'Edit Data Produk', '2017-10-16 14:36:00');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1266, 'sn02', 0, 'Edit Data Produk', '2017-10-16 14:38:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1267, 'sn07', 0, 'Edit Data Produk', '2017-10-16 14:39:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1268, 'st05', 0, 'Edit Data Produk', '2017-10-16 14:39:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1269, 'st04', 0, 'Edit Data Produk', '2017-10-16 14:40:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1270, 'sn08', 0, 'Edit Data Produk', '2017-10-16 14:40:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1271, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:41:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1272, 'bt30', 0, 'Tambah Data Produk', '2017-10-16 14:42:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1273, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:43:59');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1274, 'sn09', 0, 'Edit Data Produk', '2017-10-16 14:45:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1275, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:45:17');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1276, 'sn07', 0, 'Edit Data Produk', '2017-10-16 14:46:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1277, 'ns03', 0, 'Edit Data Produk', '2017-10-16 14:48:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1278, 'sy15', 0, 'Edit Data Produk', '2017-10-16 14:48:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1279, 'ns04', 0, 'Edit Data Produk', '2017-10-16 14:50:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1280, 'ns02', 0, 'Edit Data Produk', '2017-10-16 14:51:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1281, 'sn03', 0, 'Edit Data Produk', '2017-10-16 14:52:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1282, 'st01', 0, 'Edit Data Produk', '2017-10-16 14:56:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1283, 'st05', 0, 'Edit Data Produk', '2017-10-16 14:58:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1284, 'sn07', 0, 'Edit Data Produk', '2017-10-16 14:58:23');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1285, 'st05', 0, 'Edit Data Produk', '2017-10-16 14:58:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1286, 'st04', 0, 'Edit Data Produk', '2017-10-16 14:59:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1287, 'sn08', 0, 'Edit Data Produk', '2017-10-16 14:59:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1288, 'st06', 0, 'Edit Data Produk', '2017-10-16 14:59:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1289, 'sn09', 0, 'Edit Data Produk', '2017-10-16 14:59:40');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1290, 'sl', 0, 'Edit Data Produk', '2017-10-16 15:00:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1291, 'es02', 0, 'Edit Data Produk', '2017-10-16 15:00:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1292, 'es03', 0, 'Edit Data Produk', '2017-10-16 15:00:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1293, 'es01', 0, 'Edit Data Produk', '2017-10-16 15:00:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1294, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1295, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1296, 'sn04', 1, 'Penjualan Produk', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1297, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1298, 'jc11', 1, 'Penjualan Produk', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1299, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1300, 'jc08', 1, 'Penjualan Produk', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1301, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1302, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1303, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1304, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1305, 'pz04', 1, 'Penjualan Produk', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1306, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1307, 'jc15', 1, 'Penjualan Produk', '2017-10-16 17:45:43');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1308, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:47:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1309, 'ac03', 1, 'Penjualan Produk', '2017-10-16 17:47:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1310, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:47:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1311, 'ac03', 1, 'Penjualan Produk', '2017-10-16 17:47:11');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1312, 'jc16', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:55:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1313, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:55:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1314, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:55:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1315, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 17:55:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1316, 'jc16', 1, 'Penjualan Produk', '2017-10-16 17:55:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1317, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:28:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1318, 'pz01', 1, 'Penjualan Produk', '2017-10-16 18:28:36');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1319, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:30:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1320, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:30:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1321, 'jc26', 1, 'Penjualan Produk', '2017-10-16 18:30:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1322, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1323, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1324, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1325, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1326, 'pz04', 1, 'Penjualan Produk', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1327, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1328, 'pz02', 1, 'Penjualan Produk', '2017-10-16 18:41:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1329, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1330, 'ns01', 1, 'Penjualan Produk', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1331, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1332, 'ns01', 1, 'Penjualan Produk', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1333, 'sy29', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1334, 'bt22', 2, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1335, 'sy22', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1336, 'sy01', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1337, 'sy08', 3, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1338, 're22', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1339, 'sn03', 1, 'Penjualan Produk', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1340, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1341, 'jc07', 1, 'Penjualan Produk', '2017-10-16 18:49:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1342, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 18:49:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1343, 'jc06', 1, 'Penjualan Produk', '2017-10-16 18:49:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1344, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1345, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1346, 'jc26', 1, 'Penjualan Produk', '2017-10-16 19:13:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1347, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:21:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1348, 'jc13', 1, 'Penjualan Produk', '2017-10-16 19:21:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1349, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:30:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1350, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:30:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1351, 'ac02', 1, 'Penjualan Produk', '2017-10-16 19:30:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1352, 'ac02', 1, 'Penjualan Produk', '2017-10-16 19:30:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1353, 'jc16', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:38:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1354, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:38:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1355, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:38:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1356, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 19:38:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1357, 'jc16', 1, 'Penjualan Produk', '2017-10-16 19:38:03');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1358, 'mt05', 180, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1359, 'sy20', 50, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1360, 're22', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1361, 'bt22', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1362, 'st03', 1, 'Penjualan Produk', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1363, 'sy33', 80, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1364, 'bt22', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1365, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1366, 'st05', 1, 'Penjualan Produk', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1367, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1368, 'st07', 1, 'Penjualan Produk', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1369, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1370, 'st10', 1, 'Penjualan Produk', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1371, 'mt03', 130, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:24');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1372, 'sy31', 150, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1373, 're14', 2, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1374, 'sy15', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1375, 'sy16', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1376, 'sy03', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1377, 'sy32', 10, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1378, 'sy19', 10, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1379, 'ns03', 1, 'Penjualan Produk', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1380, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1381, 'jc09', 1, 'Penjualan Produk', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1382, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1383, 'jc09', 1, 'Penjualan Produk', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1384, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1385, 'jc14', 1, 'Penjualan Produk', '2017-10-16 20:02:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1386, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:04:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1387, 'ac10', 1, 'Penjualan Produk', '2017-10-16 20:04:12');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1388, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:25:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1389, 'ac03', 1, 'Penjualan Produk', '2017-10-16 20:25:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1390, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:25:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1391, 'ac02', 1, 'Penjualan Produk', '2017-10-16 20:25:09');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1392, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:27:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1393, 'sp01', 1, 'Penjualan Produk', '2017-10-16 20:27:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1394, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:35:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1395, 'pz01', 1, 'Penjualan Produk', '2017-10-16 20:35:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1396, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:35:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1397, 'jc15', 1, 'Penjualan Produk', '2017-10-16 20:35:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1398, 'jc16', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:36:21');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1399, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:36:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1400, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:36:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1401, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:36:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1402, 'jc16', 1, 'Penjualan Produk', '2017-10-16 20:36:22');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1403, 'sy29', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1404, 'bt22', 2, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1405, 'sy22', 5, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1406, 'sy01', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1407, 'sy08', 3, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1408, 're22', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1409, 'sn03', 1, 'Penjualan Produk', '2017-10-16 20:42:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1410, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1411, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1412, 'jc26', 1, 'Penjualan Produk', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1413, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1414, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1415, 'jc26', 1, 'Penjualan Produk', '2017-10-16 20:42:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1416, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:52:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1417, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 20:52:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1418, 'sn04', 1, 'Penjualan Produk', '2017-10-16 20:52:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1419, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:07:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1420, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:07:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1421, 'jc26', 1, 'Penjualan Produk', '2017-10-16 21:07:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1422, 'jc16', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:15:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1423, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:15:27');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1424, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:15:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1425, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:15:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1426, 'jc16', 1, 'Penjualan Produk', '2017-10-16 21:15:28');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1427, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 21:39:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1428, 'ac02', 1, 'Penjualan Produk', '2017-10-16 21:39:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1429, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1430, 'ac10', 1, 'Penjualan Produk', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1431, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1432, 'ac10', 1, 'Penjualan Produk', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1433, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1434, 'ac11', 1, 'Penjualan Produk', '2017-10-16 22:31:38');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1435, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:32:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1436, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:32:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1437, 'pz03', 1, 'Penjualan Produk', '2017-10-16 22:32:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1438, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:32:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1439, 'jc02', 1, 'Penjualan Produk', '2017-10-16 22:32:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1440, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:37:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1441, 'ac03', 1, 'Penjualan Produk', '2017-10-16 22:37:55');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1442, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:40:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1443, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:40:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1444, 'sn04', 1, 'Penjualan Produk', '2017-10-16 22:40:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1445, 'jc16', 1, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:53:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1446, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:53:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1447, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:53:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1448, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 22:53:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1449, 'jc16', 1, 'Penjualan Produk', '2017-10-16 22:53:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1450, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 23:08:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1451, 'ac03', 1, 'Penjualan Produk', '2017-10-16 23:08:06');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1452, 'mt02', 0, 'Pengurangan Data Produk (Penjualan)', '2017-10-16 23:27:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1453, 'ac03', 1, 'Penjualan Produk', '2017-10-16 23:27:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1454, 'sn01', 0, 'Edit Data Produk', '2017-10-17 14:12:50');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1455, 'sn04', 0, 'Edit Data Produk', '2017-10-17 14:13:16');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1456, 'sn05', 0, 'Edit Data Produk', '2017-10-17 14:13:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1457, 'st02', 0, 'Edit Data Produk', '2017-10-17 14:13:37');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1458, 'st01', 0, 'Edit Data Produk', '2017-10-17 14:13:48');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1459, 'st03', 0, 'Edit Data Produk', '2017-10-17 14:14:20');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1460, 'sn12', 0, 'Edit Data Produk', '2017-10-17 14:14:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1461, 'st09', 0, 'Edit Data Produk', '2017-10-17 14:15:08');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1462, 'sn13', 0, 'Edit Data Produk', '2017-10-17 14:15:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1463, 'sn06', 0, 'Edit Data Produk', '2017-10-17 14:16:01');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1464, 'ns02', 0, 'Edit Data Produk', '2017-10-17 14:16:31');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1465, 'ns04', 0, 'Edit Data Produk', '2017-10-17 14:16:42');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1466, 'ns03', 0, 'Edit Data Produk', '2017-10-17 14:16:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1467, 'pz02', 0, 'Edit Data Produk', '2017-10-17 14:17:26');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1468, 'pz01', 0, 'Edit Data Produk', '2017-10-17 14:17:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1469, 'pz03', 0, 'Edit Data Produk', '2017-10-17 14:17:49');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1470, 'pz05', 0, 'Edit Data Produk', '2017-10-17 14:18:25');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1471, 'sn07', 0, 'Edit Data Produk', '2017-10-17 14:18:52');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1472, 'sn09', 0, 'Edit Data Produk', '2017-10-17 14:19:15');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1473, 'sl', 0, 'Edit Data Produk', '2017-10-17 14:19:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1474, 'es03', 0, 'Edit Data Produk', '2017-10-17 14:19:45');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1475, 'es02', 0, 'Edit Data Produk', '2017-10-17 14:19:54');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1476, 'es01', 0, 'Edit Data Produk', '2017-10-17 14:20:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1477, 'jc01', 0, 'Edit Data Produk', '2017-10-17 14:20:35');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1478, 'jc15', 0, 'Edit Data Produk', '2017-10-17 14:20:47');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1479, 'jc06', 0, 'Edit Data Produk', '2017-10-17 14:20:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1480, 'jc07', 0, 'Edit Data Produk', '2017-10-17 14:21:10');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1481, 'jc19', 0, 'Edit Data Produk', '2017-10-17 14:21:57');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1482, 'jc22', 0, 'Tambah Data Produk', '2017-10-17 14:22:51');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1483, 'jc09', 0, 'Edit Data Produk', '2017-10-17 14:23:19');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1484, 'jc25', 0, 'Tambah Data Produk', '2017-10-17 14:23:56');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1485, 'jc10', 0, 'Edit Data Produk', '2017-10-17 14:24:32');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1486, 'jc27', 0, 'Tambah Data Produk', '2017-10-17 14:25:13');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1487, 'jc11', 0, 'Edit Data Produk', '2017-10-17 14:25:39');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1488, 'jc28', 0, 'Tambah Data Produk', '2017-10-17 14:26:05');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1489, 'jc08', 0, 'Edit Data Produk', '2017-10-17 14:26:29');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1490, 'jc29', 0, 'Tambah Data Produk', '2017-10-17 14:27:07');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1491, 'ac02', 0, 'Edit Data Produk', '2017-10-17 14:28:04');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1492, 'ac04', 0, 'Edit Data Produk', '2017-10-17 14:28:18');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1493, 'ac03', 0, 'Edit Data Produk', '2017-10-17 14:28:41');
INSERT INTO log (`id`, `idProduk`, `qty`, `namaTransaksi`, `waktu`) VALUES (1494, 'ac14', 0, 'Edit Data Produk', '2017-10-17 14:29:23');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS menu;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `ext_1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 7, 1, 1, 'yes', '', '', '', '');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `size` varchar(55) NOT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  `jml_cf1` int(11) NOT NULL,
  `jml_cf2` int(11) NOT NULL,
  `jml_cf3` int(11) NOT NULL,
  `jml_cf4` int(11) NOT NULL,
  `jml_cf5` int(11) NOT NULL,
  `jml_cf6` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `track_quantity` tinyint(4) DEFAULT '1',
  `details` varchar(1000) DEFAULT NULL,
  `menu` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (2, 'mt02', 'tenderloin buff', 'gr', 'gr', '90.00', '90.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (3, 'mt03', 'oxtail', 'gr', 'gr', '130.00', '130.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -130, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (4, 'mt04', 'backrib', 'pcs', 'pcs', '95.00', '95.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (5, 'mt05', 'chicken breast', 'gr', 'gr', '45.00', '45.00', 5000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -1080, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (6, 'mt06', 'brisket', 'kg', 'kg', '35000.00', '35000.00', 1, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (7, 'mt07', 'chicken wing', 'pcs', 'pcs', '0.00', '0.00', 150, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (8, 'mt08', 'ayam pejantan', 'pcs', 'pcs', '10000.00', '10000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (9, 'mt09', 'sosis ayam champ', 'gr', 'gr', '45.00', '45.00', 2000, 'no_image.jpg', 3, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (10, 'mt10', 'sosis sapi champ', 'gr', 'gr', '45.00', '45.00', 2000, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (11, 'mt11', 'smoked beef', 'pcs', 'pcs', '10000.00', '10000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (12, 'mt12', 'sosis ayam endura', 'pcs', 'pcs', '5000.00', '5000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (13, 'mt13', 'sosis sapi endura', 'pcs', 'pcs', '5000.00', '5000.00', 50, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (14, 'bt01', 'kecap bango', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (15, 'bt02', 'saus tomat', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (16, 'bt03', 'saus sambal', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (17, 'bt04', 'minyak wijen', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (18, 'bt05', 'olive oil', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -95, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (19, 'bt06', 'saus tiram', 'gr', 'ge', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (20, 'bt07', 'l&p', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (21, 'bt08', 'kecap ikan', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (22, 'bt09', 'kecap inggris', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (23, 'bt10', 'red wine', '-', '-', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (24, 'bt11', 'white wine', '-', '-', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (25, 'bt12', 'kikoman', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (26, 'bt13', 'tobasco', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (27, 'bt14', 'tomato paste', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (28, 'bt15', 'cooking cream', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (29, 'bt16', 'cuka', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (30, 'bt17', 'sunquick orange', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (31, 'bt18', 'sunquick lemon', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (32, 'bt19', 'marjan strawberry', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (33, 'bt20', 'jamur kaleng', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (35, 'bt22', 'chicken knorr', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -6, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (36, 'bt23', 'maggie sapi', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (37, 'bt24', 'mustard', 'gr', 'gr', '200.00', '200.00', 2000, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (38, 'ot01', 'tepung segitiga biru', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (39, 'ot02', 'tepung kanji', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (40, 'ot03', 'tepung roti', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (41, 'ot04', 'spagheti', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (42, 'ot05', 'butter', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (43, 'ot06', 'pengembang', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (44, 'ot07', 'mayonaise', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (45, 'ot08', 'mozarella', 'gr', 'gr', '95.00', '95.00', 6800, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (46, 'ot09', 'cheddar', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (47, 'ot10', 'parmesan', 'gr', 'gr', '300.00', '300.00', 1000, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (48, 're01', 'thyme', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (49, 're02', 'oregano', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -95, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (50, 're03', 'rosemary', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (51, 're04', 'bayleaves', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (52, 're05', 'chili powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (53, 're06', 'garlic powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (54, 're07', 'biji pala', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (55, 're08', 'biji lada hitam', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -95, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (56, 're09', 'onion powder', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (57, 're10', 'astaranis', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (58, 're11', 'kemiri', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (59, 're12', 'ketumbar', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (60, 're13', 'cengkeh', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (61, 're14', 'bawang goreng', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -2, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (62, 're15', 'paya', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (63, 're16', 'terasi', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (64, 're17', 'lada putih', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (66, 're19', 'gula', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (67, 're20', 'merica', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (68, 're21', 'kapulaga', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 5, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (69, 'sy01', 'daun jeruk', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -2, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (70, 'sy02', 'daun bawang', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (71, 'sy03', 'seledri', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -1, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (72, 'sy04', 'salam', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (73, 'sy05', 'sereh', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (74, 'sy06', 'bawang merah', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (75, 'sy07', 'bawang bombay', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (77, 'sy08', 'bawang putih', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -6, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (78, 'sy09', 'lengkuas', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (79, 'sy10', 'jahe', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (80, 'sy11', 'kunyit', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (81, 'sy12', 'kencur', 'gr', 'gr', '150.00', '150.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (82, 'sy13', 'daun pisang', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (83, 'sy14', 'caisim', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, '83', '31', '66', '', '', '', 50, 20, 10, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (84, 'sy15', 'jeruk nipis', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -1, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (85, 'sy16', 'tomat', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -5, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (86, 'sy17', 'timun', 'gr', 'gr', '150.00', '150.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (87, 'sy18', 'selada', 'gr', 'gr', '100.00', '100.00', 500, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (88, 'sy19', 'wortel', 'gr', 'gr', '100.00', '100.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (90, 'sy21', 'cabe hijau', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (91, 'sy22', 'cabe merah', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (92, 'sy23', 'semangka', 'gr', 'gr', '250.00', '250.00', 2000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (93, 'sy24', 'melon', 'gr', 'gr', '250.00', '250.00', 2000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (94, 'sy25', 'alpukat', 'gr', 'gr', '300.00', '300.00', 2000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (95, 'sy26', 'apel', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (96, 'sy27', 'kiwi', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (97, 'sy28', 'anggur', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (98, 'sy29', 'tahu', 'pcs', 'pcs', '3000.00', '3000.00', 40, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -2, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (99, 'sy30', 'tempe', 'gr', 'gr', '200.00', '200.00', 1000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (100, 'sy31', 'beras', 'gr', 'gr', '500.00', '500.00', 20000, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -150, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (103, 'mt01', 'sirloin australia', 'gr', 'gr', '31.00', '31.00', 5000, 'no_image.jpg', 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -2520, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (104, 'st01', 'imported us sirloin steak', 'pcs', 'pcs', '53000.00', '135000.00', 20000, 'no_image.jpg', 7, 1, '103', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (105, 'st02', 'imported tenderloin steak', 'pcs', 'pcs', '40000.00', '135000.00', 20000, 'no_image.jpg', 7, 1, '2', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (106, 'st03', 'chicken steak', 'pcs', 'pcs', '25000.00', '85000.00', 20000, 'no_image.jpg', 7, 1, '5', '89', '65', '55', '49', '18', 180, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (107, 'st04', 'potato wedges', 'pcs', 'pcs', '5000.00', '0.00', 20000, 'no_image.jpg', 7, 1, '118', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (108, 'st05', 'french fries', 'pcs', 'pcs', '5000.00', '0.00', 20000, 'no_image.jpg', 7, 1, '117', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (109, 'st06', 'mashed potato', 'pcs', 'pcs', '5000.00', '0.00', 20000, 'no_image.jpg', 7, 1, '102', '', '', '', '', '', 80, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (110, 'st07', 'bbq sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (111, 'st08', 'blackpepper sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (112, 'st09', 'mushroom sauce', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (113, 'st10', 'well done', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (114, 'st11', 'medium well', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (115, 'st12', 'medium', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (116, 'st13', 'imported back ribs', 'pcs', 'pcs', '50000.00', '150000.00', 0, 'no_image.jpg', 7, 1, '4', '89', '65', '55', '49', '18', 250, 50, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (117, 'sy33', 'french fries bahan', 'gr', 'gr', '35.00', '35.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, -80, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (118, 'sy34', 'wedges bahan', 'gr', 'gr', '40.00', '40.00', 1000, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (119, 'sn01', 'signature chicken wing', 'pcs', 'pcs', '15000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '7', '38', '120', '40', '52', '110', 3, 15, 1, 20, 3, 10, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (120, 'ot11', 'telur', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (121, 'sn02', 'omelette', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '120', '46', '65', '55', '117', '13', 2, 20, 5, 5, 80, 1, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (122, 'sn03', 'spicy tofu', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 3, '98', '90', '69', '77', '35', '', 2, 5, 5, 5, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (123, 'sn04', 'spicy cireng', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 7, 3, '38', '39', '90', '77', '69', '35', 20, 20, 5, 5, 5, 20, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (124, 'sn05', 'onion ring', 'pcs', 'pcs', '10000.00', '25000.00', 0, 'no_image.jpg', 7, 3, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 6, '41', '18', '90', '77', '35', '55', 120, 40, 5, 5, 5, 5, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 6, '41', '18', '90', '77', '35', '55', 120, 40, 5, 5, 10, 10, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (127, 'sn06', 'french fries with sausage', 'pcs', 'pcs', '20000.00', '40000.00', 0, 'no_image.jpg', 7, 3, '117', '12', '13', '35', '52', '', 80, 1, 1, 10, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (128, 'ns01', 'nasi goreng bandung', 'pcs', 'pcs', '20000.00', '45000.00', 0, 'no_image.jpg', 7, 2, '100', '120', '8', '21', '14', '75', 120, 2, 50, 10, 10, 20, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (129, 'ns02', 'sop buntut', 'pcs', 'pcs', '25000.00', '70000.00', 0, 'no_image.jpg', 7, 2, '3', '100', '84', '', '', '', 150, 120, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (130, 'ns03', 'sop buntut bakar', 'pcs', 'pcs', '25000.00', '80000.00', 0, 'no_image.jpg', 7, 2, '100', '3', '', '', '', '', 120, 150, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (131, 'ns04', 'sop buntut goreng', 'pcs', 'pcs', '25000.00', '80000.00', 0, 'no_image.jpg', 7, 2, '100', '3', '', '', '', '', 120, 150, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (132, 'ns05', 'ayam taliwang', 'pcs', 'pcs', '20000.00', '55000.00', 0, 'no_image.jpg', 7, 2, '8', '100', '98', '99', '133', '', 1, 120, 1, 1, 50, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (133, 'sy35', 'kangkung', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (134, 'ot12', 'dough', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 4, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (135, 'pz01', 'pizza meat lovers', 'pcs', 'pcs', '15000.00', '60000.00', 0, 'no_image.jpg', 7, 7, '134', '11', '9', '10', '45', '49', 1, 1, 60, 30, 60, 1, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (136, 'pz02', 'california pizza', 'pcs', 'pcs', '15000.00', '60000.00', 0, 'no_image.jpg', 7, 7, '134', '11', '10', '75', '49', '137', 1, 1, 30, 30, 1, 40, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (137, 'sy36', 'paprika', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (138, 'pz03', 'big cheese pizza', 'pcs', 'pcs', '20000.00', '65000.00', 0, 'no_image.jpg', 7, 7, '134', '46', '45', '47', '139', '', 1, 60, 60, 20, 10, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (139, 'sy37', 'susu kental manis', 'gr', 'gr', '10000.00', '0.00', 0, 'no_image.jpg', 6, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (140, 'pz04', 'nutella cheese pizza', 'pcs', 'pcs', '15000.00', '50000.00', 0, 'no_image.jpg', 7, 7, '134', '139', '45', '141', '', '', 1, 10, 60, 40, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (141, 'bt25', 'nutella', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (142, 'sl', 'fruit salad', 'pcs', 'pcs', '15000.00', '30000.00', 0, 'no_image.jpg', 7, 8, '95', '96', '97', '', '', '', 1, 1, 6, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (143, 'sn07', 'extra french fries', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 7, 3, '117', '35', '52', '', '', '', 160, 20, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (144, 'sn08', 'extra wedges potato', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 7, 3, '118', '35', '52', '', '', '', 160, 20, 20, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (145, 'sn09', 'extra mashed potatoes', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 7, 3, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (146, 'sn10', 'extra bbq sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (147, 'sn11', 'extra black pepper sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (148, 'sn12', 'extra mushroom sauce', 'pcs', 'pcs', '0.00', '10000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (149, 'sn13', 'extra spinach', 'pcs', 'pcs', '0.00', '20000.00', 0, 'no_image.jpg', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (150, 'pz05', 'extra cheese', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (151, 'pz06', 'extra nutella cheese', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (152, 'ns06', 'nasi putih', 'pcs', 'pcs', '0.00', '8000.00', 0, 'no_image.jpg', 7, 2, '100', '', '', '', '', '', 120, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (153, 'es01', 'chocolate ice cream', 'gr', 'gr', '5000.00', '20000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (154, 'es02', 'strawberry ice cream', 'gr', 'gr', '5000.00', '20000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (155, 'es03', 'vanilla ice cream', 'pcs', 'pcs', '5000.00', '20000.00', 0, 'no_image.jpg', 9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (156, 'jc01', 'avocado juice', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 8, 5, '94', '139', '66', '', '', '', 150, 20, 10, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (157, 'jc02', 'melon juice', '-', '', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '93', '66', '', '', '', '', 200, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (158, 'jc03', 'watermelon juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '92', '66', '', '', '', '', 200, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (159, 'jc04', 'orange juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '30', '66', '', '', '', '', 20, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (160, 'jc05', 'lemon juice', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '160', '66', '', '', '', '', 20, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (161, 'jc06', 'sawi juice', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 8, 5, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (162, 'jc07', 'seledri juice', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 8, 5, '71', '31', '66', '', '', '', 30, 10, 10, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (163, 'jc08', 'ice cappucino', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 5, '164', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (164, 'bt26', 'capucino sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (165, 'jc09', 'ice teh tarik', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 5, '166', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (166, 'bt27', 'teh tarik sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (167, 'jc10', 'ice milo', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 5, '168', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (168, 'bt28', 'milo sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (169, 'jc11', 'ice lemon tea', 'pcs', 'pcs', '5000.00', '20000.00', 0, 'no_image.jpg', 8, 5, '170', '66', '', '', '', '', 1, 10, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (170, 'bt29', 'lemon tea sachet', 'pcs', 'pcs', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (171, 'jc12', 'strawberry milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '154', '139', '66', '', '', '', 50, 30, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (172, 'jc13', 'chocolate milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '153', '66', '139', '', '', '', 50, 20, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (173, 'jc14', 'vanilla milkshake', 'pcs', 'pcs', '10000.00', '30000.00', 0, 'no_image.jpg', 8, 5, '155', '66', '139', '', '', '', 50, 20, 30, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (174, 'jc15', 'watermelon strawberry juice', 'pcs', 'pcs', '10000.00', '35000.00', 0, 'no_image.jpg', 8, 5, '92', '32', '', '', '', '', 200, 20, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (175, 'jc16', 'coca cola', 'pcs', 'pcs', '3750.00', '15000.00', 48, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 19, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (176, 'jc17', 'fanta', 'pcs', 'pcs', '3750.00', '15000.00', 48, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (177, 'jc18', 'sprite', 'pcs', 'pcs', '3750.00', '15000.00', 48, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (178, 'jc19', 'ice tea', 'pcs', 'pcs', '5000.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (179, 'jc20', 'lemon squash', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (180, 'jc21', 'cola float', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (181, 'jc23', 'orange squash', 'pcs', 'pcs', '0.00', '25000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (182, 'jc24', 'fanta float', 'pcs', 'pcs', '0.00', '30000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (183, 'jc26', 'mineral water', 'pcs', 'pcs', '2000.00', '5000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 23, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (184, 'ac01', 'anker stout 330ml', 'pcs', 'pcs', '20000.00', '40000.00', 72, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (185, 'ac02', 'bintang 330ml', 'pcs', 'pcs', '14000.00', '30000.00', 120, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (186, 'ac03', 'bintang radler lemon', 'pcs', 'pcs', '14000.00', '30000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (187, 'ac04', 'bintang radler grape fruit', 'psc', 'pcs', '14000.00', '30000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (188, 'ac05', 'carlsberg 330ml', 'pcs', 'pcs', '17500.00', '35000.00', 48, 'no_image.jpg', 8, 4, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (189, 'ac06', 'guiness 330ml', 'pcs', 'pcs', '21000.00', '40000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (190, 'ac07', 'heineken 330ml', 'pcs', 'pcs', '19000.00', '35000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (191, 'ac08', 'heineken light 330ml', 'pcs', 'pcs', '19000.00', '35000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (192, 'ac09', 'anker 620ml', 'pcs', 'psc', '25000.00', '50000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (193, 'ac10', 'bintang 620ml', 'pcs', 'pcs', '25000.00', '50000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (194, 'ac11', 'guiness 620ml', 'pcs', 'pcs', '34000.00', '60000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (195, 'ac12', 'heineken 620ml', 'psc', 'pcs', '34000.00', '60000.00', 48, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (196, 'ac13', 'prost 620 ml', 'pcs', 'pcs', '27830.00', '50000.00', 24, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (197, 'ac14', 'prost 330 ml', 'pcs', 'pcs', '15620.00', '30000.00', 24, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 48, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (198, 'ac15', 'mix max blueberry', 'pcs', 'pcs', '17600.00', '35000.00', 24, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 12, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (199, 'ac16', 'mix max cranberry', 'pcs', 'pcs', '17600.00', '35000.00', 12, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 12, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (200, 'ac17', 'mix max classic', 'pcs', 'pcs', '17600.00', '35000.00', 12, 'no_image.jpg', 8, 4, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 12, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (201, 'sy20', 'bayam', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -50, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (202, 're18', 'garam', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (203, 're22', 'parsley', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -3, 1, 0, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (204, 'sy32', 'kentang', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, -10, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (205, 'bt30', 'susu cair', 'gr', 'gr', '0.00', '0.00', 0, 'no_image.jpg', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 0);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (206, 'jc22', 'hot tea', 'pcs', 'pcs', '5000.00', '15000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (207, 'jc25', 'hot teh tarik', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (208, 'jc27', 'hot milo', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 1, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (209, 'jc28', 'hot lemon tea', 'pcs', 'pcs', '5000.00', '20000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `jml_cf1`, `jml_cf2`, `jml_cf3`, `jml_cf4`, `jml_cf5`, `jml_cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`, `menu`) VALUES (210, 'jc29', 'hot cappucino', 'pcs', 'pcs', '5000.00', '25000.00', 0, 'no_image.jpg', 8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 1, 0, '', 1);


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (5, 2, 196, 'ac13', 'prost 620 ml', 24, '27830.00', NULL, '667920.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (6, 2, 197, 'ac14', 'prost 330 ml', 48, '15620.00', NULL, '749760.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (7, 2, 198, 'ac15', 'mix max blueberry', 12, '17600.00', NULL, '211200.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (8, 2, 199, 'ac16', 'mix max cranberry', 12, '17600.00', NULL, '211200.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (9, 2, 200, 'ac17', 'mix max classic', 12, '17600.00', NULL, '211200.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (10, 1, 175, 'jc16', 'coca cola', 24, '0.00', NULL, '0.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (11, 1, 176, 'jc17', 'fanta', 24, '0.00', NULL, '0.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (12, 1, 177, 'jc18', 'sprite', 24, '0.00', NULL, '0.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (13, 3, 183, 'jc26', 'mineral water', 23, '2000.00', NULL, '46000.00', 1, '0.00', '0.00');


#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  `inv_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (1, 'PO-0001', 3, 1, 'setia', '2017-10-15', '', '0.00', 'Owner Owner', 'Owner Owner', '0.00', '0.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (2, 'PO-0002', 3, 2, 'akp', '2017-10-15', '', '2051280.00', 'Owner Owner', NULL, '0.00', '2051280.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (3, 'PO-0003', 3, 4, 'tompotiksa', '2017-10-17', '', '46000.00', 'Owner Owner', NULL, '0.00', '46000.00');


#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=429 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (1, 1, 101, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (2, 2, 101, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (3, 3, 104, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '130000.00', '130000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (4, 4, 104, 'st01', 'australian sirloin steik', 'pcs', 1, '0.00', 1, '130000.00', '130000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (5, 5, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (6, 6, 146, 'sn10', 'extra bbq sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (7, 7, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (8, 8, 147, 'sn11', 'extra black pepper sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (9, 9, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (10, 10, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (11, 11, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (12, 12, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (13, 13, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (14, 14, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (15, 14, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (16, 14, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (17, 14, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (18, 14, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (19, 15, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (20, 15, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (21, 15, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (22, 15, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (23, 15, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (24, 16, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (25, 17, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (26, 17, 136, 'pz02', 'california pizza', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (27, 17, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (28, 18, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (29, 18, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (30, 19, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (31, 20, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (32, 20, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (33, 20, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (34, 20, 150, 'pz05', 'extra chesse', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (35, 21, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (36, 21, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (37, 21, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (38, 22, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (39, 22, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (40, 22, 190, 'ac07', 'heineken 330ml', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (41, 22, 121, 'sn02', 'omelette', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (42, 23, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (43, 23, 192, 'ac09', 'anker 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (44, 23, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (45, 23, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (46, 23, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (47, 23, 179, 'jc20', 'lemon squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (48, 23, 192, 'ac09', 'anker 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (49, 23, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (50, 23, 192, 'ac09', 'anker 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (51, 24, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (52, 24, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (53, 25, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (54, 25, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (55, 25, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (56, 25, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (57, 25, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (58, 25, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (59, 25, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (60, 25, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (61, 25, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (62, 26, 132, 'ns05', 'ayam taliwang', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (63, 26, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (64, 26, 190, 'ac07', 'heineken 330ml', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (65, 26, 179, 'jc20', 'lemon squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (66, 26, 190, 'ac07', 'heineken 330ml', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (67, 27, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (68, 27, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (69, 27, 172, 'jc13', 'chocolate milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (70, 27, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (71, 27, 131, 'ns04', 'sop buntut goreng', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (72, 28, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (73, 28, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (74, 28, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (75, 28, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (76, 28, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (77, 28, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (78, 28, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (79, 28, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (80, 28, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (81, 29, 179, 'jc20', 'lemon squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (82, 29, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (83, 29, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (84, 29, 167, 'jc10', 'ice milo', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (85, 29, 109, 'st06', 'mashed potato', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (86, 29, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (87, 30, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (88, 30, 109, 'st06', 'mashed potato', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (89, 30, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (90, 30, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (91, 30, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (92, 30, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (93, 30, 162, 'jc07', 'seledri juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (94, 31, 104, 'st01', 'imported us sirloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (95, 31, 111, 'st08', 'blackpepper sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (96, 31, 104, 'st01', 'imported us sirloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (97, 31, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (98, 31, 124, 'sn05', 'onion ring', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (99, 31, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (100, 31, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (101, 31, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (102, 31, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (103, 31, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (104, 31, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (105, 31, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (106, 31, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (107, 32, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (108, 32, 148, 'sn12', 'extra seventh sin sauce', 'pcs', 1, '0.00', 1, '10000.00', '10000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (109, 32, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (110, 32, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (111, 32, 111, 'st08', 'blackpepper sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (112, 32, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (113, 32, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (114, 32, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (115, 32, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (116, 32, 109, 'st06', 'mashed potato', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (117, 33, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (118, 33, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (119, 33, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (120, 33, 173, 'jc14', 'vanilla milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (121, 33, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (122, 33, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (123, 33, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (124, 34, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (125, 34, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (126, 34, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (127, 34, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (128, 35, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (129, 35, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (130, 35, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (131, 35, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (132, 35, 171, 'jc12', 'strawberry milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (133, 35, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (134, 35, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (135, 35, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (136, 35, 136, 'pz02', 'california pizza', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (137, 35, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (138, 35, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (139, 35, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (140, 35, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (141, 35, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (142, 35, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (143, 35, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (144, 35, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (145, 35, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (146, 35, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (147, 35, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (148, 35, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (149, 35, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (150, 35, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (151, 35, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (152, 36, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (153, 36, 161, 'jc06', 'sawi juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (154, 36, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (155, 36, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (156, 37, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (157, 37, 131, 'ns04', 'sop buntut goreng', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (158, 37, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (159, 37, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (160, 38, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (161, 39, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (162, 39, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (163, 39, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (164, 39, 144, 'sn08', 'extra wedges potato', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (165, 39, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (166, 39, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (167, 39, 159, 'jc04', 'orange juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (168, 39, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (169, 39, 181, 'jc23', 'orange squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (170, 40, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (171, 40, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (172, 40, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (173, 40, 142, 'sl', 'fruit salad', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (174, 40, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (175, 40, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (176, 40, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (177, 40, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (178, 40, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (179, 40, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (180, 40, 162, 'jc07', 'seledri juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (181, 40, 143, 'sn07', 'extra french fries', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (182, 40, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (183, 40, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (184, 41, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (185, 41, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (186, 41, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (187, 41, 104, 'st01', 'imported us sirloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (188, 41, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (189, 41, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (190, 41, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (191, 41, 124, 'sn05', 'onion ring', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (192, 41, 181, 'jc23', 'orange squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (193, 41, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (194, 41, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (195, 41, 172, 'jc13', 'chocolate milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (196, 41, 129, 'ns02', 'sop buntut', 'pcs', 1, '0.00', 1, '65000.00', '65000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (197, 42, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (198, 42, 161, 'jc06', 'sawi juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (199, 42, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (200, 43, 104, 'st01', 'imported us sirloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (201, 43, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (202, 43, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (203, 43, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (204, 43, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (205, 43, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (206, 43, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (207, 43, 115, 'st12', 'medium', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (208, 43, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (209, 43, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (210, 43, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (211, 43, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (212, 43, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (213, 44, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (214, 44, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (215, 44, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (216, 44, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (217, 44, 129, 'ns02', 'sop buntut', 'pcs', 1, '0.00', 1, '65000.00', '65000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (218, 44, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (219, 44, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (220, 44, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (221, 44, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (222, 44, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (223, 44, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (224, 44, 181, 'jc23', 'orange squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (225, 44, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (226, 45, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (227, 45, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (228, 45, 111, 'st08', 'blackpepper sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (229, 45, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (230, 45, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (231, 45, 111, 'st08', 'blackpepper sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (232, 45, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (233, 45, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (234, 45, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (235, 45, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (236, 45, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (237, 45, 159, 'jc04', 'orange juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (238, 45, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (239, 45, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (240, 45, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (241, 45, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (242, 45, 178, 'jc19', 'tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (243, 46, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (244, 46, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (245, 46, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (246, 46, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (247, 46, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (248, 46, 112, 'st09', 'seventhsin sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (249, 46, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (250, 47, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (251, 47, 172, 'jc13', 'chocolate milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (252, 47, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (253, 48, 105, 'st02', 'imported tenderloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (254, 48, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (255, 48, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (256, 48, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (257, 48, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (258, 48, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (259, 49, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (260, 50, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (261, 50, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (262, 50, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (263, 50, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (264, 50, 161, 'jc06', 'sawi juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (265, 50, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (266, 50, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (267, 50, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (268, 50, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (269, 50, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (270, 50, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (271, 51, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (272, 51, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (273, 51, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (274, 51, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (275, 51, 158, 'jc03', 'watermelon juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (276, 51, 161, 'jc06', 'sawi juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (277, 51, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (278, 51, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (279, 51, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (280, 51, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (281, 51, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (282, 52, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (283, 52, 167, 'jc10', 'ice milo', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (284, 52, 167, 'jc10', 'ice milo', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (285, 52, 181, 'jc23', 'orange squash', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (286, 52, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (287, 52, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (288, 52, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (289, 52, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (290, 52, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (291, 52, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (292, 52, 143, 'sn07', 'extra french fries', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (293, 52, 180, 'jc21', 'cola float', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (294, 52, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (295, 52, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (296, 52, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (297, 52, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (298, 52, 136, 'pz02', 'california pizza', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (299, 52, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (300, 52, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (301, 52, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (302, 52, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (303, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (304, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (305, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (306, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (307, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (308, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (309, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (310, 52, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (311, 53, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (312, 54, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (313, 54, 109, 'st06', 'mashed potato', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (314, 54, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (315, 54, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (316, 54, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (317, 54, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (318, 54, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (319, 54, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (320, 54, 104, 'st01', 'imported us sirloin steak', 'pcs', 1, '0.00', 1, '125000.00', '125000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (321, 54, 111, 'st08', 'blackpepper sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (322, 54, 109, 'st06', 'mashed potato', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (323, 54, 114, 'st11', 'medium well', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (324, 54, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (325, 54, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (326, 54, 152, 'ns06', 'nasi putih', 'pcs', 1, '0.00', 1, '8000.00', '8000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (327, 54, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (328, 54, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (329, 54, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (330, 54, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (331, 54, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (332, 55, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (333, 55, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (334, 55, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (335, 55, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (336, 55, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (337, 55, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (338, 56, 116, 'st13', 'imported back ribs', 'pcs', 1, '0.00', 1, '150000.00', '150000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (339, 56, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (340, 56, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (341, 56, 173, 'jc14', 'vanilla milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (342, 56, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (343, 56, 190, 'ac07', 'heineken 330ml', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (344, 56, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (345, 56, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (346, 56, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (347, 57, 126, 'sp02', 'spaghetti aglio olio with smoked beef', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (348, 57, 107, 'st04', 'potato wedges', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (349, 57, 129, 'ns02', 'sop buntut', 'pcs', 1, '0.00', 1, '65000.00', '65000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (350, 57, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (351, 57, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (352, 57, 187, 'ac04', 'bintang radler grape fruit', 'psc', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (353, 57, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (354, 57, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (355, 58, 190, 'ac07', 'heineken 330ml', 'pcs', 1, '0.00', 1, '35000.00', '35000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (356, 59, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (357, 59, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (358, 59, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (359, 59, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (360, 59, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (361, 59, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (362, 59, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (363, 59, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (364, 59, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (365, 60, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (366, 60, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (367, 60, 162, 'jc07', 'seledri juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (368, 60, 159, 'jc04', 'orange juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (369, 60, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (370, 60, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (371, 60, 195, 'ac12', 'heineken 620ml', 'psc', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (372, 60, 143, 'sn07', 'extra french fries', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (373, 61, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (374, 61, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (375, 62, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (376, 62, 169, 'jc11', 'ice lemon tea', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (377, 62, 163, 'jc08', 'ice cappucino', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (378, 62, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (379, 62, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (380, 63, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (381, 63, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (382, 64, 175, 'jc16', 'coca cola', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (383, 65, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (384, 66, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (385, 67, 140, 'pz04', 'nutella cheese pizza', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (386, 67, 136, 'pz02', 'california pizza', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (387, 68, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (388, 68, 128, 'ns01', 'nasi goreng bandung', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (389, 68, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (390, 68, 162, 'jc07', 'seledri juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (391, 68, 161, 'jc06', 'sawi juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (392, 69, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (393, 70, 172, 'jc13', 'chocolate milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (394, 71, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (395, 72, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (396, 73, 175, 'jc16', 'coca cola', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (397, 74, 106, 'st03', 'chicken steak', 'pcs', 1, '0.00', 1, '80000.00', '80000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (398, 74, 108, 'st05', 'french fries', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (399, 74, 110, 'st07', 'bbq sauce', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (400, 74, 113, 'st10', 'well done', 'pcs', 1, '0.00', 1, '0.00', '0.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (401, 74, 130, 'ns03', 'sop buntut bakar', 'pcs', 1, '0.00', 1, '70000.00', '70000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (402, 74, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (403, 74, 165, 'jc09', 'teh tarik', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (404, 74, 173, 'jc14', 'vanilla milkshake', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (405, 75, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (406, 76, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (407, 76, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (408, 77, 125, 'sp01', 'spaghetti aglio olio with chicken', 'pcs', 1, '0.00', 1, '45000.00', '45000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (409, 78, 135, 'pz01', 'pizza meat lovers', 'pcs', 1, '0.00', 1, '55000.00', '55000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (410, 78, 174, 'jc15', 'watermelon strawberry juice', 'pcs', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (411, 79, 175, 'jc16', 'coca cola', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (412, 80, 122, 'sn03', 'spicy tofu', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (413, 81, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (414, 81, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (415, 82, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (416, 83, 183, 'jc26', 'mineral water', 'pcs', 1, '0.00', 1, '5000.00', '5000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (417, 84, 175, 'jc16', 'coca cola', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (418, 85, 185, 'ac02', 'bintang 330ml', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (419, 86, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (420, 86, 193, 'ac10', 'bintang 620ml', 'pcs', 1, '0.00', 1, '50000.00', '50000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (421, 86, 194, 'ac11', 'guiness 620ml', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (422, 87, 138, 'pz03', 'big cheese pizza', 'pcs', 1, '0.00', 1, '60000.00', '60000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (423, 87, 157, 'jc02', 'melon juice', '-', 1, '0.00', 1, '30000.00', '30000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (424, 88, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (425, 89, 123, 'sn04', 'spicy cireng', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (426, 90, 175, 'jc16', 'coca cola', 'pcs', 1, '0.00', 1, '15000.00', '15000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (427, 91, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (428, 92, 186, 'ac03', 'bintang radler lemon', 'pcs', 1, '0.00', 1, '25000.00', '25000.00', '0.00', '', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `pos` tinyint(4) NOT NULL DEFAULT '0',
  `paid` decimal(25,2) DEFAULT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_holder` varchar(100) DEFAULT NULL,
  `cheque_no` varchar(20) DEFAULT NULL,
  `noMeja` varchar(25) NOT NULL,
  `pelayan` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (1, 'SL-0001', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '125000.00', '0.00', '125000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '125000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (2, 'SL-0002', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '125000.00', '0.00', '125000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '125000.00', '', '', '', '13', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (3, 'SL-0003', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '130000.00', '0.00', '130000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '150000.00', '', '', '', '1', 'Owner');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (4, 'SL-0004', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '130000.00', '0.00', '130000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '150000.00', '', '', '', '2', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (5, 'SL-0005', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '3', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (6, 'SL-0006', 2, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (7, 'SL-0007', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (8, 'SL-0008', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-12', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '10000.00', '', '', '', '1', 'kasir');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (9, 'SL-0009', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (10, 'SL-0010', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (11, 'SL-0011', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (12, 'SL-0012', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-14', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '100000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (13, 'SL-0013', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '100000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (14, 'SL-0014', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '105000.00', '0.00', '105000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 5, '0.00', 1, '105000.00', '', '', '', '1', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (15, 'SL-0015', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '105000.00', '0.00', '105000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 5, '0.00', 1, '105000.00', '', '', '', '1', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (16, 'SL-0016', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '1', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (17, 'SL-0017', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '115000.00', '0.00', '115000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '150000.00', '', '', '', '2', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (18, 'SL-0018', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '10000.00', '', '', '', '1', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (19, 'SL-0019', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (20, 'SL-0020', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '145000.00', '0.00', '145000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '145000.00', '', '', '', '6', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (21, 'SL-0021', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '90000.00', '0.00', '90000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '100000.00', '', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (22, 'SL-0022', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '140000.00', '0.00', '140000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '150000.00', '', '', '', '7', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (23, 'SL-0023', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '345000.00', '0.00', '345000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 9, '0.00', 1, '345000.00', '', '', '', '3', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (24, 'SL-0024', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '80000.00', '0.00', '80000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '80000.00', '', '', '', '10', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (25, 'SL-0025', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '255000.00', '0.00', '255000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 9, '0.00', 1, '255000.00', '', '', '', '4', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (26, 'SL-0026', 1, 1, 'HARUN', 1, 'GENERAL CUSTOMER', '2017-10-13', NULL, NULL, '210000.00', '0.00', '210000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 5, '0.00', 1, '210000.00', '', '', '', '5', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (27, 'SL-0027', 1, 1, 'HARUN', 0, 'ruut', '2017-10-14', NULL, NULL, '190000.00', '0.00', '190000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 5, '0.00', 1, '190000.00', '', '', '', '1', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (28, 'SL-0028', 1, 1, 'HARUN', 0, 'dering', '2017-10-14', NULL, NULL, '235000.00', '0.00', '235000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 9, '0.00', 1, '250000.00', '', '', '', '2', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (29, 'SL-0029', 1, 1, 'HARUN', 0, 'fadel', '2017-10-14', NULL, NULL, '100000.00', '0.00', '100000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 6, '0.00', 1, '100000.00', '', '', '', '5', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (30, 'SL-0030', 1, 1, 'HARUN', 0, 'candra', '2017-10-14', NULL, NULL, '220000.00', '0.00', '220000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 7, '0.00', 1, '220000.00', '', '', '', '7', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (31, 'SL-0031', 1, 1, 'HARUN', 0, 'anto', '2017-10-14', NULL, NULL, '470000.00', '0.00', '470000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 13, '0.00', 1, '500000.00', '', '', '', '3', '4');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (32, 'SL-0032', 1, 1, 'HARUN', 0, 'willy', '2017-10-14', NULL, NULL, '295000.00', '0.00', '295000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 10, '0.00', 1, '295000.00', '', '', '', '8', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (33, 'SL-0033', 1, 1, 'HARUN', 0, 'widya', '2017-10-14', NULL, NULL, '170000.00', '0.00', '170000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 7, '0.00', 1, '200000.00', '', '', '', '4', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (34, 'SL-0034', 1, 1, 'HARUN', 0, 'abe', '2017-10-14', NULL, NULL, '100000.00', '0.00', '100000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 4, '0.00', 1, '100000.00', '', '', '', '9', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (35, 'SL-0035', 1, 1, 'HARUN', 0, 'sam', '2017-10-14', NULL, NULL, '745000.00', '0.00', '745000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 24, '0.00', 1, '750000.00', '', '', '', '6', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (36, 'SL-0036', 1, 1, 'HARUN', 0, 'fictor', '2017-10-14', NULL, NULL, '135000.00', '0.00', '135000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 4, '0.00', 1, '150000.00', '', '', '', '10', '4');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (37, 'SL-0037', 1, 1, 'HARUN', 0, 'ervans', '2017-10-14', NULL, NULL, '105000.00', '0.00', '105000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 5, '0.00', 1, '110000.00', '', '', '', '11', '4');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (38, 'SL-0038', 1, 1, 'HARUN', 0, 'ervans', '2017-10-14', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '11', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (39, 'SL-0039', 1, 1, 'HARUN', 0, 'enog', '2017-10-15', NULL, NULL, '315000.00', '0.00', '315000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 9, '0.00', 1, '350000.00', '', '', '', '2', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (40, 'SL-0040', 1, 1, 'HARUN', 0, 'yuki', '2017-10-15', NULL, NULL, '330000.00', '0.00', '330000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 14, '0.00', 1, '350000.00', '', '', '', '21', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (41, 'SL-0041', 1, 1, 'HARUN', 0, 'iyas', '2017-10-15', NULL, NULL, '470000.00', '0.00', '470000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 13, '0.00', 1, '500000.00', '', '', '', '3', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (42, 'SL-0042', 1, 1, 'HARUN', 0, 'ito', '2017-10-15', NULL, NULL, '90000.00', '0.00', '90000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 3, '0.00', 1, '100000.00', '', '', '', '25', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (43, 'SL-0043', 1, 1, 'HARUN', 0, 'jems', '2017-10-15', NULL, NULL, '395000.00', '0.00', '395000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 13, '0.00', 1, '395000.00', '', '', '', '4', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (44, 'SL-0044', 1, 1, 'HARUN', 0, 'll', '2017-10-15', NULL, NULL, '670000.00', '0.00', '670000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 13, '0.00', 1, '700000.00', '', '', '', '14', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (45, 'SL-0045', 1, 1, 'HARUN', 0, 'yanis', '2017-10-15', NULL, NULL, '680000.00', '0.00', '680000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 17, '0.00', 1, '700000.00', '', '', '', '5', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (46, 'SL-0046', 1, 1, 'HARUN', 0, 'lina', '2017-10-15', NULL, NULL, '325000.00', '0.00', '325000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 8, '0.00', 1, '350000.00', '', '', '', '24', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (47, 'SL-0047', 1, 1, 'HARUN', 0, 'fitri', '2017-10-15', NULL, NULL, '105000.00', '0.00', '105000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 3, '0.00', 1, '105000.00', '', '', '', '8', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (48, 'SL-0048', 1, 1, 'HARUN', 0, 'ronly', '2017-10-15', NULL, NULL, '200000.00', '0.00', '200000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 7, '0.00', 1, '250000.00', '', '', '', '6', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (49, 'SL-0049', 1, 1, 'HARUN', 0, 'ronly', '2017-10-15', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '6', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (50, 'SL-0050', 1, 1, 'HARUN', 0, 'ibu cinta', '2017-10-15', NULL, NULL, '275000.00', '0.00', '275000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 11, '0.00', 1, '0.00', '', '', '', '26', '4');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (51, 'SL-0051', 1, 1, 'HARUN', 0, 'cinta', '2017-10-15', NULL, NULL, '275000.00', '0.00', '275000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 11, '0.00', 1, '275000.00', '', '', '', '26', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (52, 'SL-0052', 1, 1, 'HARUN', 0, 'ishak', '2017-10-15', NULL, NULL, '865000.00', '0.00', '865000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 29, '0.00', 1, '865000.00', '', '', '', '22', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (53, 'SL-0053', 1, 1, 'HARUN', 0, 'ishak', '2017-10-15', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '22', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (54, 'SL-0054', 1, 1, 'HARUN', 0, 'bu wulan', '2017-10-15', NULL, NULL, '708000.00', '0.00', '708000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 20, '0.00', 1, '708000.00', '', '', '', '7', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (55, 'SL-0055', 1, 1, 'HARUN', 0, 'lisa', '2017-10-15', NULL, NULL, '170000.00', '0.00', '170000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 6, '0.00', 1, '170000.00', '', '', '', '29', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (56, 'SL-0056', 1, 1, 'HARUN', 0, 'bastian', '2017-10-15', NULL, NULL, '365000.00', '0.00', '365000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 9, '0.00', 1, '365000.00', '', '', '', '27', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (57, 'SL-0057', 1, 1, 'HARUN', 0, 'asgar', '2017-10-15', NULL, NULL, '235000.00', '0.00', '235000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 8, '0.00', 1, '235000.00', '', '', '', '30', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (58, 'SL-0058', 1, 1, 'HARUN', 0, 'bastian', '2017-10-15', NULL, NULL, '35000.00', '0.00', '35000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '35000.00', '', '', '', '27', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (59, 'SL-0059', 1, 1, 'HARUN', 0, 'oci', '2017-10-15', NULL, NULL, '215000.00', '0.00', '215000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 9, '0.00', 1, '215000.00', '', '', '', '31', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (60, 'SL-0060', 1, 1, 'HARUN', 0, 'lisa', '2017-10-15', NULL, NULL, '295000.00', '0.00', '295000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 8, '0.00', 1, '295000.00', '', '', '', '28', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (61, 'SL-0061', 1, 1, 'HARUN', 0, 'ervan', '2017-10-15', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '55000.00', '', '', '', '32', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (62, 'SL-0062', 1, 1, 'HARUN', 0, 'iin', '2017-10-16', NULL, NULL, '145000.00', '0.00', '145000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 5, '0.00', 1, '145000.00', '', '', '', '33', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (63, 'SL-0063', 1, 1, 'HARUN', 0, 'iin', '2017-10-16', NULL, NULL, '50000.00', '0.00', '50000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '50000.00', '', '', '', '33', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (64, 'SL-0064', 1, 1, 'HARUN', 0, 'ilham', '2017-10-16', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '36', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (65, 'SL-0065', 1, 1, 'HARUN', 0, 'ilham', '2017-10-16', NULL, NULL, '55000.00', '0.00', '55000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '55000.00', '', '', '', '36', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (66, 'SL-0066', 1, 1, 'HARUN', 0, 'iin', '2017-10-16', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '33', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (67, 'SL-0067', 1, 1, 'HARUN', 0, 'galib', '2017-10-16', NULL, NULL, '105000.00', '0.00', '105000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '105000.00', '', '', '', '2', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (68, 'SL-0068', 1, 1, 'HARUN', 0, 'pak leo', '2017-10-16', NULL, NULL, '175000.00', '0.00', '175000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 5, '0.00', 1, '175000.00', '', '', '', '10', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (69, 'SL-0069', 1, 1, 'HARUN', 0, 'iin', '2017-10-16', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '33', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (70, 'SL-0070', 1, 1, 'HARUN', 0, 'cici', '2017-10-16', NULL, NULL, '30000.00', '0.00', '30000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '30000.00', '', '', '', '37', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (71, 'SL-0071', 1, 1, 'HARUN', 0, 'ilham', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '36', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (72, 'SL-0071', 1, 1, 'HARUN', 0, 'ilham', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '36', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (73, 'SL-0073', 1, 1, 'HARUN', 0, 'ervan', '2017-10-16', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '', '1');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (74, 'SL-0074', 1, 1, 'HARUN', 0, 'yangyang', '2017-10-16', NULL, NULL, '230000.00', '0.00', '230000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 8, '0.00', 1, '230000.00', '', '', '', '32', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (75, 'SL-0075', 1, 1, 'HARUN', 0, 'yangyang', '2017-10-16', NULL, NULL, '50000.00', '0.00', '50000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '50000.00', '', '', '', '32', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (76, 'SL-0076', 1, 1, 'HARUN', 0, 'alber', '2017-10-16', NULL, NULL, '50000.00', '0.00', '50000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '50000.00', '', '', '', '38', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (77, 'SL-0077', 1, 1, 'HARUN', 0, 'ervans', '2017-10-16', NULL, NULL, '45000.00', '0.00', '45000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '45000.00', '', '', '', '5', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (78, 'SL-0078', 1, 1, 'HARUN', 0, 'eric', '2017-10-16', NULL, NULL, '85000.00', '0.00', '85000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '85000.00', '', '', '', '9', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (79, 'SL-0079', 1, 1, 'HARUN', 0, 'eric', '2017-10-16', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '9', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (80, 'SL-0080', 1, 1, 'HARUN', 0, 'ervans', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '5', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (81, 'SL-0081', 1, 1, 'HARUN', 0, 'ervans', '2017-10-16', NULL, NULL, '10000.00', '0.00', '10000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '10000.00', '', '', '', '5', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (82, 'SL-0082', 1, 1, 'HARUN', 0, 'ervans', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '5', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (83, 'SL-0083', 1, 1, 'HARUN', 0, 'eric', '2017-10-16', NULL, NULL, '5000.00', '0.00', '5000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '5000.00', '', '', '', '9', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (84, 'SL-0084', 1, 1, 'HARUN', 0, 'david', '2017-10-16', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '2', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (85, 'SL-0085', 1, 1, 'HARUN', 0, 'ervans', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '5', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (86, 'SL-0086', 1, 1, 'HARUN', 0, 'yansen', '2017-10-16', NULL, NULL, '160000.00', '0.00', '160000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 3, '0.00', 1, '160000.00', '', '', '', '37', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (87, 'SL-0087', 1, 1, 'HARUN', 0, 'yansen', '2017-10-16', NULL, NULL, '90000.00', '0.00', '90000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 2, '0.00', 1, '90000.00', '', '', '', '37', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (88, 'SL-0088', 1, 1, 'HARUN', 0, 'david', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '6', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (89, 'SL-0089', 1, 1, 'HARUN', 0, 'david', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '6', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (90, 'SL-0090', 1, 1, 'HARUN', 0, 'stiker', '2017-10-16', NULL, NULL, '15000.00', '0.00', '15000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '15000.00', '', '', '', '10', '3');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (91, 'SL-0091', 1, 1, 'HARUN', 0, 'stiker', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '10', '2');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`, `noMeja`, `pelayan`) VALUES (92, 'SL-0092', 1, 1, 'HARUN', 0, 'david', '2017-10-16', NULL, NULL, '25000.00', '0.00', '25000.00', NULL, NULL, '0.00', 1, '0.00', 0, 'kasir kasir', NULL, 'cash', 1, '0.00', 1, '25000.00', '', '', '', '6', '3');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '2.3',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `restrict_sale` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_user` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_calendar` tinyint(4) NOT NULL DEFAULT '0',
  `bstatesave` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`, `restrict_sale`, `restrict_user`, `restrict_calendar`, `bstatesave`) VALUES (1, 'seventhsin_2001.png', 'login_logo.png', 'SEVENTHSIN', 'arabic', 1, 'RP.', 2, 3, 50, 9, 30, '2.3', 5, 5, 'SL', 'QU', 'PO', 'TR', 'code128', 'cosmo', 1, 1, 2, 2, 1, 1, 0, 0, 0, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (1, 7, 'mm01', 'steik');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (2, 7, 'mm02', 'nasi');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (3, 7, 'mm03', 'snack');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (4, 8, 'mn01', 'alcohol');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (5, 8, 'mn02', 'non alcohol');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (6, 7, 'mm04', 'spaghetti');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (7, 7, 'mm05', 'pizza');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (8, 7, 'mm06', 'salad');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'setia', 'setia', 'rajamoili', 'Palu', 'Sulawesi Tengah', '4000', 'indo', '000000000', 'setia@yahoo.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'akp', 'akp', 'tondo', 'palu', 'Sulawesi Tengah', '4000', 'indo', '123456789789', 'akp@yahoo.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (3, 'bns', 'bns', 's. parman', 'Palu', 'Sulawesi Tengah', '4000', 'indo', '123456789', 'bns@yahoo.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (4, 'tompotiksa', 'tompotika', 'palu', 'Palu', 'Sulawesi Tengah', '4000', 'indo', '123456456', 'tompotika@yahoo.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(50) NOT NULL,
  `namaCustomer` varchar(50) NOT NULL,
  `noMeja` varchar(25) NOT NULL,
  `pelayan` varchar(25) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, '10%', '10.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (5, 'tax and service', '15.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `tax_val` decimal(25,2) DEFAULT NULL,
  `unit_price` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO transfer_items (`id`, `transfer_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `quantity`, `tax_rate_id`, `tax`, `tax_val`, `unit_price`, `gross_total`) VALUES (2, 1, 175, 'jc16', 'coca cola', 'pcs', 1, 1, '0.00', '0.00', '0.00', '0.00');


#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) DEFAULT NULL,
  `tr_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO transfers (`id`, `transfer_no`, `date`, `from_warehouse_id`, `from_warehouse_code`, `from_warehouse_name`, `to_warehouse_id`, `to_warehouse_code`, `to_warehouse_name`, `note`, `user`, `total_tax`, `total`, `tr_total`) VALUES (1, 'TR-0001', '2017-10-16', 3, 'gd03', 'bar', 4, 'gd04', 'gudang bs', '&lt;p&gt;\r\n belum update system\r\n&lt;/p&gt;', 'Owner Owner', '0.00', '0.00', '0.00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'owner', '92bebcbea72ab95e402191a132947a1800d973b0', NULL, 'owner@seventhsin.com', NULL, NULL, NULL, 'dec3b7325cb8ce7662774167b86bf65f3915aa08', 1351661704, 1508225413, 1, 'Owner', 'Owner', 'Stock Manager', '0105292122');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (2, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'kasir kasir', '14b15286a09f294628547606a91d138867f3351a', NULL, 'yannri.zenner@gamantha.com', NULL, NULL, NULL, NULL, 1471921682, 1475808726, 1, 'kasir', 'kasir', 'gamantha', '1212312312312');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (3, '��	', 'kasir kasir1', '0955437a010c2d76618deb0bcd0fb5362f17bdd6', NULL, 'kasir@seventhsin.com', NULL, NULL, NULL, NULL, 1506839680, 1508146671, 1, 'kasir', 'kasir', 'seventhsin', '123456789789');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (4, '��', 'zenner zee', 'e1993c5256e43d0321e1af9ef6b4ca139a8fe3b5', NULL, 'pembelian@seventhsin.com', NULL, NULL, NULL, NULL, 1506850992, 1506851019, 1, 'zenner', 'zee', 'seventhsin', '3454657889900');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (2, 2, 4);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (3, 3, 4);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (4, 4, 2);


#
# TABLE STRUCTURE FOR: waiters
#

DROP TABLE IF EXISTS waiters;

CREATE TABLE `waiters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `kontak` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (1, 'Waiter1', 'Alamat Waiter1', 'Kontak Waiter1');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (2, 'Waiter2', 'Alamat Waiter2', 'Kontak Waiter2 ');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (3, 'Waiter3', 'Alamat Waiter3', 'Kontak Waiter3');
INSERT INTO waiters (`id`, `nama`, `alamat`, `kontak`) VALUES (4, 'Waiter4', 'Alamat Waiter4', 'Kontak Waiter4');


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (1, 'gd01', 'gudang inventory', '.\r\n', 'Palu');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (2, 'gd02', 'dapur', 'Yos Sudarso', 'Palu');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (3, 'gd03', 'bar', 'Yos Sudarso', 'Palu');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (4, 'gd04', 'gudang bs', 'Yos Sudarso', 'Palu');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (28, 16, 2, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (29, 57, 1, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (30, 18, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (32, 104, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (33, 147, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (34, 146, 2, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (35, 183, 1, -15);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (36, 132, 1, -5);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (37, 128, 1, -6);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (38, 136, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (39, 178, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (40, 169, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (41, 126, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (42, 135, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (43, 150, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (44, 158, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (45, 186, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (46, 190, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (47, 121, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (48, 122, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (49, 192, 1, -3);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (50, 138, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (51, 179, 1, -2);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (52, 123, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (53, 185, 1, -4);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (54, 163, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (55, 172, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (56, 131, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (57, 105, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (58, 112, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (59, 108, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (60, 113, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (61, 106, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (62, 107, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (63, 167, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (64, 109, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (65, 110, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (66, 125, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (67, 162, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (68, 111, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (69, 124, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (70, 140, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (71, 148, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (72, 174, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (73, 193, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (74, 173, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (75, 165, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (76, 171, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (77, 187, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (78, 130, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (79, 161, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (80, 175, 3, 23);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (81, 176, 3, 24);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (82, 177, 3, 24);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (83, 196, 3, 24);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (84, 197, 3, 48);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (85, 198, 3, 12);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (86, 199, 3, 12);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (87, 200, 3, 12);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (88, 144, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (89, 159, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (90, 181, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (91, 142, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (92, 143, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (93, 129, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (94, 116, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (95, 115, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (96, 180, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (97, 114, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (98, 152, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (99, 195, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (100, 175, 4, 1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (101, 194, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (102, 157, 1, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (103, 183, 3, 23);


